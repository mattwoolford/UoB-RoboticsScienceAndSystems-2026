# hamad's-sim5 — Doorway memory

> **90-degree, forwards-only controller (2026-11-20):** `Navigator.java` was rewritten. The robot never spins on the spot, never reverses and never drives back over its own track. Every in-place turn is exactly 90 degrees left or right (encoder heading); while driving it only makes small steering corrections (under about 10 degrees). It follows a wall on its right, or on its left if it starts beside a left wall (this avoids U-turns). Wall ahead -> turn 90 away from the followed wall. Followed wall ends -> turn 90 into the gap straight away (the back-facing side sensor notices the gap about 74 mm late, which puts the robot at the centre of a 150 mm gap) and drive through; if it was not a real gap, the wall ahead makes it turn 90 back and carry on. About 1 m of clear travel -> tentative stop. Limitation: without reversing it cannot measure a gap first, so gaps narrower than about 130 mm are attempted and may be clipped. Start roughly square to the walls (random starts face 0/90/180/270 deg; rotate buttons step 90 deg). Tested: 24/24 from square starts, also with noise + motor mismatch, and 24/24 at 3 and 5 deg tilt; 18/24 at 10 deg. 0 mm reversing and 0 mm retracing in every test. The old scanning controller (MODEL_NOTES.txt) no longer runs.

> **Single-box variant (2026-11-16):** `MapLayout.java` now builds ONE box, the old main room (715 x 500.5 mm wall centre lines) with its left doorway closed. Its 150 mm bottom doorway is the only opening and leads outside. The map is drawn from the wall rectangles, so `data/arena_map.png` is no longer needed. The three-room text below describes the original sim5.

> **IR reflection + diffusion (2026-11-16):** new `IRReflection.java`. Each sensor's beam spreads as a Gaussian cone. Light returns from the box sides by inverse-square distance and the angle it hits the wall (Lambertian), plus a second reflection where light bounces off one side onto another and back. A wall straight ahead still gives the original reading curve. Settings are at the bottom of `SimulationSettings.java`. Press **I** (or the button) to compare with the original sensor model. Red lines in the view are second-reflection paths; the sensor cards show the share of light arriving that way.

> **Diffuse scattering (2026-11-17):** matte box sides now also scatter light in every direction (Lambertian). Scattered light that lands on another side is scattered again, and the part that reaches a receiver is added to its reading. Magenta lines show these paths; the sensor cards show the scattered share. Settings: `IR_DIFFUSE_SCATTER`, `SCATTER_RAYS`, `SCATTER_IN_PLANE_FRACTION` in `SimulationSettings.java`.

> **Realistic reflectance + return pulses (2026-11-17):** box sides now reflect only `WALL_ALBEDO` = 0.65 of the IR (the rest is absorbed), and only 5% of that is mirror-like (`WALL_MIRROR_FRACTION`), as for matte cardboard. The view animates IR pulses along each beam: most vanish at the wall, and only a few (about 4-11% near walls) return into the sensor, drawn as outlined dots with a short trail. The animation is visual only; readings come from the model.

Sim5 fixes sim4's early stop after an internal doorway. **The three-room layout, openings, robot size, IR response and motor/encoder model are unchanged.** The controller uses sensor readings and relative odometry; it is not given the map or the actual exit position.

## Run

1. Extract the ZIP and open **`sim5/sim5.pde`** in **Processing 4 → Java mode**.
2. Keep all Java/PDE files together in a folder named `sim5`, then click **Run**.
3. Try **Run escape**, click a start in any room, or use **Batch: 20 starts**.
4. Press **V** to see remembered doorways. **D0, D1…** are discovered passage IDs, not preset map labels.
5. **Save CSV before resetting.** The `logs` folder contains sensor/odometry traces, controller events and the batch summary.

## What changed?

- **Continue after crossing:** clear the doorway, find a wall and resume exploration.
- **Remember passages:** store their estimated position, orientation, connections and crossing count. Recognise the same doorway from either direction.
- **Avoid immediate re-entry:** pass a remembered entry doorway while exploring the room's boundary.
- **Allow backtracking:** after an estimated boundary loop, return through the entry if that branch has been explored. Permanently banning that doorway would trap the robot in a dead end.
- **Remove single-box assumptions:** no finish immediately after crossing and no stopping boundary based on the old box dimensions.

The original right-wall following and body-clearance checks remain the base. Limits are now **15 simulated minutes / 25 m of travel** to allow exploration of several rooms.

## Results on the unchanged layout

| Test | Result |
|---|---|
| Same 20 starting poses as sim4 | **20/20 escapes**; sim4 achieved 1/20 |
| 24 additional centre/corner starts across all rooms | **24/24 escapes** |
| 4 starts with ADC noise and motor mismatch enabled | **4/4 escapes** |

**No collisions in these 48 trials.** Seventeen of the default trials used deliberate backtracking. Evidence is in `results/`.

## Is it universal?

**It does not guarantee escape from every layout.** This is a prototype for connected rooms with suitable clearance and mostly right-angle walls.

The stop is explicitly **tentative**: roughly **1 m of clear travel**, followed by a clear full scan. A large room or corridor could look the same, so the simulator independently checks whether the whole robot is actually outside. This rule adds travel beyond the exit and does not prove outside using IR alone. No exit markers or layout changes were added.

See `MODEL_NOTES.txt` for algorithm details, assumptions and verification instructions. The original GNU GPL v3 `LICENSE` is retained.
