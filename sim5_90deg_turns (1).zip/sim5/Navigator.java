import java.util.ArrayList;

// sim5 90-DEGREE CONTROLLER.
// Runtime inputs are ADC readings, relative encoder odometry and time.
// The controller has no world pose, map, opening coordinates or outside flag.
//
// The robot never spins on the spot to scan. Every in-place turn is exactly
// 90 degrees LEFT or RIGHT, measured with the encoder heading. While driving
// it holds a straight line and makes small steering corrections to keep the
// followed wall at a steady distance. It follows a wall on the RIGHT by
// default, or on the LEFT when it starts beside a left wall, so it never has
// to make a U-turn (two 90s in one place) and drive back along its own track.
//
//   wall ahead              -> turn 90 AWAY from the followed wall
//   followed wall ends      -> turn 90 TOWARDS it (the back-facing side sensor
//                              notices the gap late, so the robot is already
//                              about at its centre) and drive straight through
//   (not a real gap)        -> wall straight ahead: turn 90 back, carry on
//
// The robot only ever drives FORWARDS: it never reverses or retraces its track.
//   long clear travel outside  -> tentative stop (does NOT prove outside)
//
// Assumes the robot starts roughly square to the walls (see TEST_LOG.md for
// the tilt it tolerates). The previous scanning controller is described in
// MODEL_NOTES.txt.
final class Navigator {
  static final int IDLE=0, COUNTDOWN=1, APPROACH=2, TURN=3, FOLLOW=4, GAP_ALIGN=5,
    CROSS=7, OPEN_PROBE=8, DONE=11, STOPPED=12;
  int state=IDLE,scans=0,moves=0,corners=0,gaps=0,leftTurns=0,rightTurns=0;
  double leftPWM=0,rightPWM=0,pathMm=0;
  String message="Choose a start, then run the escape test.";
  long started,stateSince;
  double previousX,previousY,movedThisStep=0;
  // wallHeading: direction of travel along the wall being followed.
  // travelHeading: straight-line heading outside wall following.
  double wallHeading,travelHeading,targetHeading,rightFiltered=4095;
  boolean wallArmed=false,openAreaCandidate=false;
  int afterTurn=FOLLOW;
  int side=1;                         // +1: followed wall on the RIGHT, -1: on the LEFT.
  double sLoss,crossX,crossY,crossHeading,clearDistance,noWallDistance,lastGapWidth,settle;
  // Wall-angle estimate: samples of {travel mm, side gap mm, heading} while following.
  final ArrayList<double[]> alignSamples=new ArrayList<double[]>();
  int alignments=0;
  // Kept for the UI/CSV: doorways actually crossed, and the event log.
  PassageMemory memory=new PassageMemory();
  final ArrayList<String> events=new ArrayList<String>();
  final ArrayList<double[]> points=new ArrayList<double[]>(); // No scan points in this controller.

  boolean active(){return state!=IDLE&&state!=DONE&&state!=STOPPED;}
  String stateName(){
    if(state==FOLLOW)return side>0?"Following right wall":"Following left wall";
    String[] names={"Ready","Starting","Driving to a wall","Turning 90 degrees","Following wall","Lining up with a gap",
      "-","Driving through the gap","Driving in open space","-","-","Open-space stop (tentative)","Stopped"};
    return state>=0&&state<names.length?names[state]:"?";
  }
  boolean start(Observation o){
    if(active())return false;
    started=o.now;pathMm=0;scans=moves=corners=gaps=leftTurns=rightTurns=0;side=1;
    previousX=o.x;previousY=o.y;wallArmed=false;rightFiltered=o.right;openAreaCandidate=false;
    memory=new PassageMemory();events.clear();points.clear();clearDistance=noWallDistance=0;
    enter(COUNTDOWN,o,"Starting: drive straight, then turn only in 90-degree steps.");return true;
  }
  void stop(String reason){state=STOPPED;leftPWM=rightPWM=0;message=reason;}
  void enter(int next,Observation o,String note){
    state=next;stateSince=o.now;leftPWM=rightPWM=0;message=note;
    events.add(String.format(java.util.Locale.US,"%d,%d,%d,%d,%d,%d,%.3f,%.3f,\"%s\"",o.now,state,memory.current,memory.doors.size(),memory.crossings,memory.backtracks,o.x,o.y,note.replace("\"","\"\"")));
  }
  // Exactly 90 degrees left (+1) or right (-1) from a reference heading.
  void turn90(Observation o,double from,int direction,int next){
    targetHeading=from+direction*Math.PI/2;afterTurn=next;
    if(direction>0)leftTurns++;else rightTurns++;
    enter(TURN,o,direction>0?"Turning LEFT 90 degrees.":"Turning RIGHT 90 degrees.");
  }
  void straight(Observation o,double heading,double base){
    double correction=clamp(NavigationSettings.HEADING_GAIN*wrap(heading-o.theta),-14,14);
    leftPWM=base-correction;rightPWM=base+correction;
  }
  static double along(Observation o,double heading){return o.x*Math.cos(heading)+o.y*Math.sin(heading);}
  boolean wallAhead(Observation o){return o.front<=NavigationSettings.FRONT_STOP;}
  int sideReading(Observation o){return side>0?o.right:o.left;}    // Back sensor on the followed side.
  int otherReading(Observation o){return side>0?o.left:o.right;}
  String sideName(){return side>0?"right":"left";}
  // Gentle steering away from a side wall that is getting too close.
  double sideSafety(Observation o){
    double steer=0;
    if(o.left<NavigationSettings.SIDE_DANGER)steer-=NavigationSettings.MAX_STEER_RAD;   // Left too close: steer right.
    if(o.right<NavigationSettings.SIDE_DANGER)steer+=NavigationSettings.MAX_STEER_RAD;  // Right too close: steer left.
    return steer;
  }
  boolean allClear(Observation o){
    int t=NavigationSettings.OPEN_RETURN_THRESHOLD;return o.front>t&&o.left>t&&o.right>t;
  }
  void beginFollow(Observation o,boolean armed,String note){beginFollow(o,armed,false,note);}
  void beginFollow(Observation o,boolean armed,boolean skipSettle,String note){
    wallArmed=armed;rightFiltered=skipSettle?sideReading(o):NavigationSettings.RIGHT_TARGET;noWallDistance=0;
    settle=skipSettle?NavigationSettings.SETTLE_AFTER_TURN_MM:0;alignSamples.clear();
    enter(FOLLOW,o,note);
  }

  void update(Observation o){
    leftPWM=rightPWM=0;if(!active())return;
    if(!Double.isFinite(o.x)||!Double.isFinite(o.y)||!Double.isFinite(o.theta)){stop("Invalid odometry.");return;}
    movedThisStep=Math.hypot(o.x-previousX,o.y-previousY);pathMm+=movedThisStep;previousX=o.x;previousY=o.y;
    if(o.now-started>NavigationSettings.RUN_LIMIT_MS||pathMm>NavigationSettings.TRAVEL_LIMIT_MM){stop("Time/travel limit reached.");return;}

    if(state==COUNTDOWN){
      if(o.now-stateSince>=NavigationSettings.COUNTDOWN_MS){
        travelHeading=o.theta;clearDistance=0;
        enter(APPROACH,o,"Driving straight until a wall is ahead.");
      }return;
    }
    if(state==APPROACH){
      if(wallAhead(o)){
        // First wall: turn so that it ends up beside us. Normally LEFT (follow
        // it on the right); RIGHT if a wall is already close on the left, so the
        // robot does not turn into that corner and have to U-turn.
        side=o.left<NavigationSettings.LEFT_BLOCKED&&o.left<o.right?-1:1;
        turn90(o,travelHeading,side,FOLLOW);return;
      }
      if(o.now-stateSince>200&&(o.right<NavigationSettings.ALONGSIDE||o.left<NavigationSettings.ALONGSIDE)){
        // A wall alongside: follow it on that side from here.
        side=o.right<=o.left?1:-1;
        wallHeading=travelHeading;beginFollow(o,sideReading(o)<NavigationSettings.RIGHT_PRESENT,true,"Wall alongside on the "+sideName()+": following it.");return;
      }
      clearDistance=allClear(o)?clearDistance+movedThisStep:0;
      if(clearDistance>=NavigationSettings.OPEN_PROBE_MM){openStop(o);return;}
      straight(o,travelHeading+sideSafety(o),NavigationSettings.DRIVE_PWM);return;
    }
    if(state==TURN){
      double error=wrap(targetHeading-o.theta);
      if(Math.abs(error)<0.012){finishTurn(o);return;}
      if(o.now-stateSince>6500){stop("90-degree turn timed out.");return;}
      double p=Math.abs(error)<0.15?NavigationSettings.TURN_FINE_PWM:NavigationSettings.TURN_PWM;
      leftPWM=-Math.signum(error)*p;rightPWM=Math.signum(error)*p;return;
    }
    if(state==FOLLOW){
      if(wallAhead(o)){corners++;turn90(o,wallHeading,side,FOLLOW);return;}
      int near=sideReading(o);
      if(settle<NavigationSettings.SETTLE_AFTER_TURN_MM){
        // Fresh from a turn: straight line on the encoder heading only.
        settle+=movedThisStep;if(near<NavigationSettings.RIGHT_PRESENT)wallArmed=true;
        straight(o,wallHeading+sideSafety(o),NavigationSettings.DRIVE_PWM);return;
      }
      rightFiltered+=0.3*(near-rightFiltered);
      if(near<NavigationSettings.RIGHT_PRESENT){wallArmed=true;noWallDistance=0;}
      if(wallArmed&&near>=NavigationSettings.RIGHT_GAP&&rightFiltered>=NavigationSettings.RIGHT_GAP-50){
        sLoss=along(o,wallHeading);gaps++;
        enter(GAP_ALIGN,o,"The "+sideName()+" wall ended: lining up with the gap (forwards only).");return;
      }
      if(!wallArmed){
        noWallDistance+=movedThisStep;
        if(noWallDistance>NavigationSettings.LOST_WALL_MM){
          travelHeading=wallHeading;clearDistance=0;
          enter(APPROACH,o,"No wall on the "+sideName()+": driving straight to the next wall.");return;
        }
      }
      // Steer away from the wall when too close, towards it when too far.
      double adjust=side*clamp(NavigationSettings.RIGHT_HEADING_GAIN*(NavigationSettings.RIGHT_TARGET-rightFiltered),
        -NavigationSettings.MAX_STEER_RAD,NavigationSettings.MAX_STEER_RAD);
      if(wallArmed)alignToWall(o);
      // Wall seen but not yet close enough to lock on: close in firmly, so gaps
      // along it are not missed.
      else if(near<NavigationSettings.ALONGSIDE)adjust=-side*NavigationSettings.MAX_STEER_RAD;
      if(otherReading(o)<NavigationSettings.SIDE_DANGER)adjust=-side*NavigationSettings.MAX_STEER_RAD;
      straight(o,wallHeading+adjust,NavigationSettings.DRIVE_PWM);return;
    }
    if(state==GAP_ALIGN){
      // Forwards only. The robot centre is already ~GAP_SENSOR_LAG_MM past the
      // gap's near edge; drive on GAP_ADVANCE_MM (0 = turn at once), then 90 into it.
      if(wallAhead(o)){corners++;turn90(o,wallHeading,side,FOLLOW);return;}
      if(along(o,wallHeading)-sLoss>=NavigationSettings.GAP_ADVANCE_MM){moves++;turn90(o,wallHeading,-side,CROSS);return;}
      straight(o,wallHeading,NavigationSettings.DRIVE_PWM);return;
    }
    if(state==CROSS){
      double travelled=along(o,crossHeading)-(crossX*Math.cos(crossHeading)+crossY*Math.sin(crossHeading));
      if(wallAhead(o)){
        // Wall ahead: not a way through after all (turn back onto the wall
        // line, forwards), or a wall in the next space.
        corners++;turn90(o,crossHeading,side,FOLLOW);return;
      }
      if(travelled>=NavigationSettings.CROSS_CLEAR_MM){
        double doorX=crossX+NavigationSettings.CROSS_DOOR_MM*Math.cos(crossHeading),doorY=crossY+NavigationSettings.CROSS_DOOR_MM*Math.sin(crossHeading);
        PassageMemory.Door d=memory.prepare(doorX,doorY,crossHeading);memory.crossed(d,pathMm);
        travelHeading=crossHeading;clearDistance=0;
        enter(OPEN_PROBE,o,"Through the gap. Driving on and looking for walls.");return;
      }
      straight(o,crossHeading,NavigationSettings.DRIVE_PWM);return;
    }
    if(state==OPEN_PROBE){
      if(wallAhead(o)){turn90(o,travelHeading,side,FOLLOW);return;}
      if(o.right<NavigationSettings.ALONGSIDE||o.left<NavigationSettings.ALONGSIDE){
        side=o.right<=o.left?1:-1;
        wallHeading=travelHeading;beginFollow(o,sideReading(o)<NavigationSettings.RIGHT_PRESENT,"Wall found on the "+sideName()+": following it.");return;
      }
      clearDistance=allClear(o)?clearDistance+movedThisStep:0;
      if(clearDistance>=NavigationSettings.OPEN_PROBE_MM){openStop(o);return;}
      straight(o,travelHeading,NavigationSettings.DRIVE_PWM);return;
    }
  }
  // If the side gap grows or shrinks steadily while driving, the robot is at an
  // angle to the wall: slope = sin(angle). Correct the 90-degree reference by
  // that angle so later 90-degree turns stay square to the walls. This is a
  // measurement while driving, not a turn.
  void alignToWall(Observation o){
    double g=sideGap(sideReading(o));
    if(g<NavigationSettings.ALIGN_MIN_GAP_MM||g>NavigationSettings.ALIGN_MAX_GAP_MM){alignSamples.clear();return;}
    alignSamples.add(new double[]{pathMm,g,o.theta});
    double span=pathMm-alignSamples.get(0)[0];
    if(span<NavigationSettings.ALIGN_WINDOW_MM)return;
    double ms=0,mg=0,mt=0;int n=alignSamples.size();
    for(double[] p:alignSamples){ms+=p[0];mg+=p[1];mt+=wrap(p[2]-wallHeading);}
    ms/=n;mg/=n;mt=wallHeading+mt/n;
    double sxx=0,sxy=0;for(double[] p:alignSamples){sxx+=(p[0]-ms)*(p[0]-ms);sxy+=(p[0]-ms)*(p[1]-mg);}
    alignSamples.clear();
    if(sxx<1e-9)return;
    double slope=clamp(sxy/sxx,-0.5,0.5),wall=mt-side*Math.asin(slope),delta=wrap(wall-wallHeading);
    if(Math.abs(delta)>NavigationSettings.ALIGN_MAX_RAD)return;     // Implausible: ignore.
    wallHeading+=NavigationSettings.ALIGN_GAIN*delta;alignments++;
  }
  // Back-right reading -> side gap (body to wall, mm) when roughly parallel.
  static double sideGap(double raw){
    double[] r={724,1103,1482,1862,2241,2621,3000,3379,3539,3596,3653,3710,3767,3823,3880,3936,3991,4046,4086};
    if(raw<=r[0])return 0;
    for(int i=1;i<r.length;i++)if(raw<=r[i])return 5*(i-1)+5*(raw-r[i-1])/(r[i]-r[i-1]);
    return 999;
  }
  void finishTurn(Observation o){
    if(afterTurn==FOLLOW){
      wallHeading=targetHeading;
      // Still a wall ahead (e.g. started in a tight corner): another 90 the same way.
      if(wallAhead(o)){corners++;turn90(o,wallHeading,side,FOLLOW);return;}
      beginFollow(o,sideReading(o)<NavigationSettings.RIGHT_PRESENT,"Following the "+sideName()+" wall.");return;
    }
    if(afterTurn==CROSS){
      crossHeading=targetHeading;crossX=o.x;crossY=o.y;
      enter(CROSS,o,"Driving straight through the gap.");return;
    }
  }
  void openStop(Observation o){
    openAreaCandidate=true;
    enter(DONE,o,"Tentative open-space stop: about 1 m of clear travel. This does not prove outside.");
  }
  static double frontDistance(double raw){
    double[] a={260,390,3500,4085,4095},d={5,10,50,100,120};
    if(raw<=a[0])return d[0];for(int i=1;i<a.length;i++)if(raw<=a[i])return d[i-1]+(d[i]-d[i-1])*(raw-a[i-1])/(a[i]-a[i-1]);return 120;
  }
  static double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
  static double wrap(double a){return Math.atan2(Math.sin(a),Math.cos(a));}
}
final class Observation {long now;int left,front,right;double x,y,theta;}
