# Sim5 — physical box-escape controller

Unzip this archive, open `sim5/sim5.pde` in **Processing 4, Java mode**, and click **Run**. Click **Run escape** or press **E** to start. **S** stops the robot. **C** saves the trial and its events into the sketch’s `logs/` folder; save before resetting.

This sketch runs the uncalibrated `opening_retry_v1` escape controller identified in physical Test 0003. It is the only controller used by Run escape, the preset starts and the batch. A trial can retry a search, hit a wall, or stop without escaping. If it keeps searching, use Stop. No second solver takes over.

## What is running

- `BoxEscapePilot.java` is the Processing Java port of the original robot’s C++ escape decisions and thresholds. The original `EscapePilot.cpp`, `EscapePilot.h` and `EscapeSettings.h` are in `reference/` for comparison; Processing does not execute them.
- `Navigator.java` connects that pilot to the existing SIM. It uses the robot’s nominal wheel geometry, reads wheel counts every 10 ms of simulation time, and delivers the latest three raw IR values to the pilot every 50 ms. The original world still samples the sensors every 20 ms. Only the left and right motor commands go back to the drive model.
- The box, opening, sensor response, drive physics and independent whole-body exit check are the ones from the supplied Sim5. The controller does not get the true robot position or the exit location. No parameters were fitted to this SIM. The optional noise and motor mismatch controls still belong to the SIM.
- The default **Box centre**, heading **0°**, puts the bottom exit on the robot’s right. Mark the same starting position and heading for a physical comparison.

## Reading a result

A **CANDIDATE** means the robot program believes it has crossed an opening. The SIM only reports **PASS** if its independent geometry check also finds the whole robot outside. The events CSV includes the controller’s reason for a retry or stop. The original CSV columns for scans and remembered doors remain for compatibility; this controller does not scan or build a doorway graph.

For verification, the default centre run cleared the box at **60.47 simulated seconds** and reached CANDIDATE at **60.80 s**, with no collision. Other trials did collide. On four input traces, this Java implementation and the original C++ controller produced identical wheel-command pairs on all **17,662** compared control ticks. Two terminal ticks where the simulator itself stopped the wheels on collision were excluded. This is a comparison of controller commands, not a prediction of how the physical robot will move.

`MODEL_NOTES.txt`, `TEST_LOG.md` and `NavigationSettings.java` are retained from the supplied sketch. Results and navigation tuning in those files refer to previous controllers, not the active pilot.
