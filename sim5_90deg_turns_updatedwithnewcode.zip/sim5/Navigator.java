import java.util.ArrayList;
import java.util.Locale;

// Sim5's adapter for the uncalibrated physical E (escape) command.
// Only BoxEscapePilot selects a driving action; no map or true pose is passed in.
final class Navigator {
  // Numbers in the original CSV layout: terminal results remain 11 and 12.
  static final int IDLE=0, SEEK=1, TURN_LEFT=2, SETTLE_LEFT=3, ACQUIRE=4,
    FOLLOW=5, CENTRE=6, TURN_RIGHT=7, SETTLE_RIGHT=8, CROSS=9, DONE=11, STOPPED=12;
  private static final String[] LABELS={"IDLE","SEEK","TURN_LEFT","SETTLE_LEFT",
    "ACQUIRE","FOLLOW","CENTRE","TURN_RIGHT","SETTLE_RIGHT","CROSS","","CANDIDATE","STOPPED"};
  // MotionSettings.h; use firmware geometry, independent of the simulator's world.
  private static final float LEFT_RADIUS_MM=16.0f, RIGHT_RADIUS_MM=16.0f,
    WHEEL_SEPARATION_MM=90.0f, COUNTS_PER_REV=358.3f;
  private static final int CONTROL_MS=10, IR_MS=50, MAX_CONTROL_GAP_MS=300,
    NO_TICKS_MS=1000, PWM_CAP=135;
  private final BoxEscapePilot pilot=new BoxEscapePilot();

  int state=IDLE,leftPWM,rightPWM,scans,corners,gaps;
  String message="Choose a start, then run the escape test.";
  boolean openAreaCandidate;
  // Existing display/CSV compatibility only. E does not scan or build a doorway graph.
  final PassageMemory memory=new PassageMemory();
  final ArrayList<double[]> points=new ArrayList<double[]>();
  final ArrayList<String> events=new ArrayList<String>();

  private int previousLeft,previousRight;
  private long tickAt,irAt,leftMovedAt,rightMovedAt;
  private float x,y,theta;

  boolean active(){return state!=IDLE&&state!=DONE&&state!=STOPPED;}
  String stateName(){return LABELS[state];}
  static double wrap(double a){return Math.atan2(Math.sin(a),Math.cos(a));} // Sim5's optical model.

  boolean start(Observation o){
    if(active())return false;
    x=y=theta=0;
    // takeBaseline(): latch real encoder values; first observation means zero travel.
    previousLeft=o.leftTicks;previousRight=o.rightTicks;
    tickAt=irAt=leftMovedAt=rightMovedAt=o.now;
    leftPWM=rightPWM=corners=gaps=0;openAreaCandidate=false;events.clear();
    pilot.begin(o.now,x,y,theta);
    if(pilot.failed()){finish(o.now,STOPPED,pilot.reason());return false;}
    state=SEEK;message="Single-box trial";event(o.now);
    return true;
  }

  void stop(String why){finish(tickAt,STOPPED,why);}
  private void finish(long now,int endState,String why){
    state=endState;message=why;leftPWM=rightPWM=0;
    openAreaCandidate=endState==DONE;
    pilot.stop();event(now);
  }
  private void event(long now){
    events.add(String.format(Locale.US,"%d,%d,%d,%d,%d,%d,%.3f,%.3f,\"%s\"",
      now,state,memory.current,memory.doors.size(),memory.crossings,memory.backtracks,x,y,message.replace("\"","\"\"")));
  }
  private static int cap(int pwm){return Math.max(-PWM_CAP,Math.min(PWM_CAP,pwm));}
  private void drive(int left,int right,long now){
    left=cap(left);right=cap(right);
    if(leftPWM==0 && left!=0)leftMovedAt=now;
    if(rightPWM==0 && right!=0)rightMovedAt=now;
    leftPWM=left;rightPWM=right;
  }

  // OdometryModel.cpp: old heading Euler integration, with signed 32-bit wheel counts.
  private boolean encoderTick(Observation o){
    // Java int subtraction wraps modulo 2^32, as in firmware countChange().
    int dl=o.leftTicks-previousLeft, dr=o.rightTicks-previousRight;
    if(dl!=0 || leftPWM==0)leftMovedAt=o.now;
    if(dr!=0 || rightPWM==0)rightMovedAt=o.now;
    previousLeft=o.leftTicks;previousRight=o.rightTicks;
    float leftDist=(float)(dl*(2*Math.PI)*LEFT_RADIUS_MM/COUNTS_PER_REV);
    float rightDist=(float)(dr*(2*Math.PI)*RIGHT_RADIUS_MM/COUNTS_PER_REV);
    float distance=(leftDist+rightDist)/2.0f;
    x+=distance*(float)Math.cos(theta);y+=distance*(float)Math.sin(theta);
    theta+=(rightDist-leftDist)/WHEEL_SEPARATION_MM;
    if((leftPWM!=0 && o.now-leftMovedAt>=NO_TICKS_MS) ||
       (rightPWM!=0 && o.now-rightMovedAt>=NO_TICKS_MS)){
      finish(o.now,STOPPED,"No encoder motion from a commanded wheel");return false;
    }
    return true;
  }
  void update(Observation o){
    if(!active())return;
    long elapsed=o.now-tickAt;
    if(elapsed<CONTROL_MS)return;
    tickAt=o.now;
    boolean freshIR=o.now-irAt>=IR_MS;
    if(freshIR)irAt=o.now;
    if(elapsed>MAX_CONTROL_GAP_MS){finish(o.now,STOPPED,"Control update late");return;}
    if(!encoderTick(o)||!freshIR)return;

    pilot.update(o.now,x,y,theta,o.left,o.front,o.right);
    if(pilot.failed()){finish(o.now,STOPPED,pilot.reason());return;}
    if(pilot.done()){finish(o.now,DONE,pilot.reason());return;}
    int next=phaseCode(pilot.stateName());
    if(next==TURN_LEFT && state!=next)corners++;
    if(next==CENTRE && state!=next)gaps++;
    boolean changed=state!=next||!message.equals(pilot.reason());
    state=next;message=pilot.reason();
    drive(pilot.left(),pilot.right(),o.now);
    if(changed)event(o.now);
  }
  private static int phaseCode(String name){
    for(int i=SEEK;i<=CROSS;i++)if(LABELS[i].equals(name))return i;
    throw new IllegalStateException("Unrecognised active firmware phase: "+name);
  }
}
// Only inputs observable on the real robot (raw ADC and quantised encoders).
final class Observation {long now;int left,front,right,leftTicks,rightTicks;}
