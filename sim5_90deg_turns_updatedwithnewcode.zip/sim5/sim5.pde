// sim5 - Same map, doorway memory and continued exploration. Processing 4 / Java mode.
import java.util.Locale;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

TwinModel model;
PFont uiFont,numberFont;
ArrayList<UiButton> buttons=new ArrayList<UiButton>();
final int INK=0xff1b2d42,MUTED=0xff63758a,BLUE=0xff225ed6;
final int[] SENSOR_COLOURS={0xff138b81,0xffdf8a20,0xff875acc};
final float WORLD_X=24,WORLD_Y=132,WORLD_W=660,WORLD_H=526;
float viewScale,originX,originY;
int previousMillis=0,accumulator=0,speedIndex=1;
final int[] SPEEDS={1,4,16,32};
long nextSeed=1;
boolean batchActive=false,showEstimates=false;
int batchIndex=0,batchPassed=0,batchFailed=0;
final int BATCH_SIZE=20;
ArrayList<String> batchRows=new ArrayList<String>();
String toast="";
// IR pulse animation (visual only): {sensor, x0, y0, x1, y1, travelled mm, length mm, returning 0/1, return chance, hit 0/1}.
ArrayList<double[]> pulses=new ArrayList<double[]>();
int pulseLastMillis=-1;
int toastUntil=0;

public void settings(){size(1100,740);}
public void setup(){
  surface.setTitle("sim5 | Single box");frameRate(60);
  uiFont=createFont("SansSerif",16,true);numberFont=createFont("Monospaced",28,true);
  model=new TwinModel(loadMap());previousMillis=millis();addButtons();
}
public void draw(){
  int now=millis(),elapsed=min(100,max(0,now-previousMillis));previousMillis=now;
  if(batchActive){
    long until=System.nanoTime()+12000000L;int steps=0;
    while(batchActive&&!model.paused&&steps++<1000&&System.nanoTime()<until){
      model.step();if(!model.control.active())finishBatchCase();
    }
    accumulator=0;
  }else{
    accumulator+=elapsed*SPEEDS[speedIndex];
    while(accumulator>=SimulationSettings.PHYSICS_STEP_MS){model.step();accumulator-=SimulationSettings.PHYSICS_STEP_MS;}
  }
  background(244,247,251);drawInterface();
}
public void addButtons(){
  buttons.add(new UiButton("start","Run escape  [E]",24,78,126,34));
  buttons.add(new UiButton("stop","STOP  [S]",162,78,92,34));
  buttons.add(new UiButton("pause","Pause",266,78,92,34));
  buttons.add(new UiButton("reset","Reset start",370,78,110,34));
  buttons.add(new UiButton("random","Random start  [N]",492,78,150,34));
  buttons.add(new UiButton("speed","",654,78,100,34));
  buttons.add(new UiButton("batch","Batch: 20 starts",766,78,150,34));
  buttons.add(new UiButton("csv","Save CSV  [C]",928,78,148,34));
  buttons.add(new UiButton("centre","Box centre",708,394,178,30));
  buttons.add(new UiButton("corner","Near corner",898,394,178,30));
  buttons.add(new UiButton("wall","Near wall",708,434,178,30));
  buttons.add(new UiButton("opening","Near opening",898,434,178,30));
  buttons.add(new UiButton("rotateLeft","+90 deg",708,481,80,30));
  buttons.add(new UiButton("rotateRight","-90 deg",996,481,80,30));
  buttons.add(new UiButton("noise","",708,530,178,30));
  buttons.add(new UiButton("bias","",898,530,178,30));
  buttons.add(new UiButton("narrow","-",708,579,36,28));
  buttons.add(new UiButton("widen","+",1040,579,36,28));
  buttons.add(new UiButton("estimates","",708,623,178,30));
  buttons.add(new UiButton("irmodel","",898,623,178,30));
}
public void drawInterface(){
  textFont(uiFont);textAlign(LEFT,BASELINE);fill(INK);textSize(25);text("sim5 / Single box, 90-degree turns",24,35);
  fill(MUTED);textSize(13);text("Box escape: opening_retry_v1. The controller uses wheel encoders to target 90-degree turns.",24,57);
  fill(BLUE);textSize(11);textAlign(RIGHT,BASELINE);text("OFFLINE / SINGLE BOX, BOTTOM EXIT",1076,37);textAlign(LEFT,BASELINE);
  drawWorld();drawCards();drawStatus();
  for(UiButton b:buttons)drawButton(b);
  fill(INK);textSize(13);text("Starting pose presets",708,379);
  textAlign(CENTER,BASELINE);text("Heading "+fmt(deg(model.startTheta),0)+" deg",892,501);
  text("Outside exit: "+fmt(model.openingWidth,0)+" mm",892,595);
  fill(MUTED);textSize(10);text("Exit is in the bottom wall",892,613);textAlign(LEFT,BASELINE);
  fill(MUTED);textSize(11);
  text("Start x "+fmt(model.startX,1)+", y "+fmt(model.startY,1)+" mm  |  "+(model.seed>0?"seed "+model.seed:"custom/preset"),708,677);
  text("Sim time "+fmt(model.now/1000.0,1)+" s  |  path "+fmt(model.truePathMm,0)+" mm",708,697);
  text("Doors "+model.control.memory.doors.size()+"  |  crossings "+model.control.memory.crossings+"  |  backtracks "+model.control.memory.backtracks+"  |  skipped "+model.control.memory.skipped,708,717);
  fill(INK);textSize(12);text("Click inside to set a start. Up/down: move 5 mm. Left/right: turn 90 degrees.",24,682);
  fill(MUTED);textSize(11);text("Space: pause. R: reset. V: scan estimates. I: IR reflection model on/off. Save before resetting.",24,704);
  text("IR response and motion are simplified models. Test outcomes are simulation evidence, not hardware validation.",24,728);
}
public void drawCards(){
  String[] labels={"A_G0 / back left","A_G1 / front","A_G4 / back right"};
  for(int i=0;i<3;i++){
    float x=708+i*126;noStroke();fill(255);rect(x,132,116,86,10);fill(SENSOR_COLOURS[i]);rect(x,132,116,4,3);
    textFont(uiFont);textSize(11);fill(MUTED);text(labels[i],x+9,153);
    textFont(numberFont);textSize(28);fill(INK);text(str(model.sensors[i].reading),x+9,187);
    textFont(uiFont);textSize(10);fill(MUTED);
    Sensor c=model.sensors[i];
    if(model.irReflection){
      textSize(9);text("via 2nd wall "+fmt(100*c.indirectShare,0)+"%",x+9,202);
      text("scattered "+fmt(100*c.scatterShare,0)+"%",x+9,213);
    }else text("lower = stronger",x+9,207);
  }
}
public void drawStatus(){
  noStroke();fill(255);rect(708,232,368,126,10);
  fill(INK);textSize(14);text((model.paused?"PAUSED / ":"")+model.control.stateName(),722,254);
  fill(model.collided||model.control.state==Navigator.STOPPED?0xffb63b3b:(model.success()?0xff087f65:BLUE));
  textSize(11);text(model.outcome(),722,276);
  fill(MUTED);textLeading(15);String message=model.control.active()?model.control.message:model.notice;
  if(model.control.state==Navigator.DONE||model.control.state==Navigator.STOPPED)message=model.control.message;
  if(millis()<toastUntil)message=toast;
  text(message,722,287,340,42);
  if(batchIndex>0){fill(BLUE);textSize(11);text("Batch "+(batchActive?batchIndex+" / "+BATCH_SIZE:"complete/stopped")+"  |  pass "+batchPassed+"  |  fail "+batchFailed,722,344);}
}
public void drawWorld(){
  noStroke();fill(255);rect(WORLD_X,WORLD_Y,WORLD_W,WORLD_H,12);
  updateDisplayedMap();
  double minX=Math.min(-40,model.map.worldX(0)),maxX=Math.max(model.width+40,model.map.worldX(model.map.imageWidth));
  double minY=Math.min(-40,model.map.worldY(model.map.imageHeight)),maxY=Math.max(model.height+40,model.map.worldY(0));
  if(model.map.side=='R')maxX=Math.max(maxX,model.width+180);
  if(model.map.side=='L')minX=Math.min(minX,-180);
  if(model.map.side=='T')maxY=Math.max(maxY,model.height+180);
  if(model.map.side=='B')minY=Math.min(minY,-180);
  for(double[] p:model.trail){minX=Math.min(minX,p[0]-85);maxX=Math.max(maxX,p[0]+85);minY=Math.min(minY,p[1]-85);maxY=Math.max(maxY,p[1]+85);}
  viewScale=min((WORLD_W-48)/(float)(maxX-minX),(WORLD_H-65)/(float)(maxY-minY));
  originX=WORLD_X+WORLD_W/2-(float)((minX+maxX)/2)*viewScale;
  originY=WORLD_Y+WORLD_H-24+(float)minY*viewScale;
  clip(WORLD_X+1,WORLD_Y+51,WORLD_W-2,WORLD_H-53);
  stroke(239,243,248);strokeWeight(1);
  for(int xx=(int)Math.floor(minX/50)*50;xx<=maxX;xx+=50)line(sx(xx),sy(minY),sx(xx),sy(maxY));
  for(int yy=(int)Math.floor(minY/50)*50;yy<=maxY;yy+=50)line(sx(minX),sy(yy),sx(maxX),sy(yy));
  imageMode(CORNER);image(surfaceImage,sx(model.map.worldX(0)),sy(model.map.worldY(0)),surfaceImage.width*viewScale,surfaceImage.height*viewScale);
  {
    double a=model.gapStart(),b=model.gapEnd(),c=(a+b)/2;
    stroke(27,153,121);strokeWeight(2);
    line(sx(model.map.exitX(a)),sy(model.map.exitY(a)),sx(model.map.exitX(b)),sy(model.map.exitY(b)));
    fill(27,130,103);textSize(11);
    float lx=sx(model.map.exitX(c)),ly=sy(model.map.exitY(c));
    if(model.map.side=='R'){textAlign(LEFT,BASELINE);lx+=8;}
    else if(model.map.side=='L'){textAlign(RIGHT,BASELINE);lx-=8;}
    else{textAlign(CENTER,BASELINE);ly+=model.map.side=='T'?-10:16;}
    text("EXIT / "+fmt(model.openingWidth,0)+" mm",lx,ly);textAlign(LEFT,BASELINE);
  }
  noFill();stroke(125,160,205,160);strokeWeight(1.5f);beginShape();for(double[] p:model.trail)vertex(sx(p[0]),sy(p[1]));endShape();
  if(showEstimates){
    noStroke();fill(190,70,130,160);
    for(double[] p:model.control.points)ellipse(sx(model.worldX(p[0],p[1])),sy(model.worldY(p[0],p[1])),4,4);
    for(PassageMemory.Door d:model.control.memory.doors){
      float dx=sx(model.worldX(d.x,d.y)),dy=sy(model.worldY(d.x,d.y));
      fill(142,63,158);ellipse(dx,dy,8,8);textSize(10);
      text("D"+d.id+" / crossed "+d.crossings,dx+7,dy-6);
    }
  }
  noFill();stroke(110,135,165,110);strokeWeight(1);ellipse(sx(model.startX),sy(model.startY),100*viewScale,100*viewScale);
  fill(MUTED);textSize(10);text("start",sx(model.startX)+6,sy(model.startY)+15);
  for(int i=0;i<3;i++){
    Sensor s=model.sensors[i];
    // Diffused beam: brighter lines carry more of the emitted light.
    for(double[] ray:s.rays){
      float w=ray.length>3?(float)ray[3]:1;
      stroke(SENSOR_COLOURS[i],(ray[2]>0?150:45)*w);strokeWeight(1);line(sx(s.sx),sy(s.sy),sx(ray[0]),sy(ray[1]));
    }
    // Second reflections: box side -> another side -> back to the receiver.
    // Shade each path by its share of everything the receiver collects
    // (a path carrying a quarter of an average ray's light is fully drawn).
    double light=s.directLight+s.indirectLight;
    if(s.reading>=4095||light<=0)continue;
    for(double[] b:s.bounces){
      float w=(float)Math.min(1,4*b[4]*SimulationSettings.DIFFUSION_RAYS/light);if(w<0.05)continue;
      stroke(205,55,55,140*w);strokeWeight(1);line(sx(b[0]),sy(b[1]),sx(b[2]),sy(b[3]));
      stroke(205,55,55,70*w);line(sx(b[2]),sy(b[3]),sx(s.sx),sy(s.sy));
    }
    // Diffuse scattering: light spread from a lit spot onto other box sides.
    for(double[] b:s.scatter){
      float w=(float)Math.min(1,4*b[4]*SimulationSettings.DIFFUSION_RAYS*SimulationSettings.SCATTER_RAYS/light);if(w<0.05)continue;
      stroke(195,60,170,110*w);strokeWeight(1);line(sx(b[0]),sy(b[1]),sx(b[2]),sy(b[3]));
      stroke(195,60,170,55*w);line(sx(b[2]),sy(b[3]),sx(s.sx),sy(s.sy));
    }
  }
  drawPulses();
  fill(model.collided?0xffffe2e2:0xffdee9fb);stroke(model.collided?0xffc44141:BLUE);strokeWeight(2);
  ellipse(sx(model.x),sy(model.y),2*(float)SimulationSettings.BODY_RADIUS_MM*viewScale,2*(float)SimulationSettings.BODY_RADIUS_MM*viewScale);
  strokeWeight(3);line(sx(model.x),sy(model.y),sx(model.x+38*Math.cos(model.theta)),sy(model.y+38*Math.sin(model.theta)));
  for(int i=0;i<3;i++){Sensor s=model.sensors[i];noStroke();fill(SENSOR_COLOURS[i]);ellipse(sx(s.sx),sy(s.sy),7,7);}
  noClip();fill(MUTED);textSize(11);text("SIMULATOR VIEW / controller does not receive this map",WORLD_X+16,WORLD_Y+22);
  text(showEstimates?"Pink dots: scan returns. D0, D1...: remembered doorways in odometry.":(model.irReflection?"Dots: IR pulses (outlined = returned to sensor). Red: mirror bounce. Magenta: scattered between sides.":"Black lines: solid walls. Green: outside exit. Scale: 1 pixel = 1 mm."),WORLD_X+16,WORLD_Y+42);
  float bx=WORLD_X+18,by=WORLD_Y+WORLD_H-16;stroke(MUTED);strokeWeight(2);line(bx,by,bx+50*viewScale,by);fill(MUTED);text("50 mm",bx+50*viewScale+8,by+4);
}
// IR pulses: each sensor sends pulses out along its diffused beam (more along
// the beam centre). When one meets a wall it usually disappears (absorbed or
// scattered elsewhere); only occasionally does one come back into the
// receiver, more often from close walls hit head-on. Purely a picture of the
// physics in IRReflection.java; the readings do not depend on it.
public void drawPulses(){
  int nowMs=millis();double dt=pulseLastMillis<0?0:Math.min(0.1,(nowMs-pulseLastMillis)/1000.0);pulseLastMillis=nowMs;
  if(!model.irReflection||batchActive){pulses.clear();return;}
  if(!model.paused){
    for(int i=0;i<3;i++){
      Sensor s=model.sensors[i];
      if(s.rays.isEmpty()||random(1)>=SimulationSettings.PULSES_PER_SECOND*dt)continue;
      double total=0;for(double[] r:s.rays)total+=r[3];
      double pick=random(1)*total;double[] ray=s.rays.get(s.rays.size()-1);
      for(double[] r:s.rays){pick-=r[3];if(pick<=0){ray=r;break;}}
      double len=Math.hypot(ray[0]-s.sx,ray[1]-s.sy);
      pulses.add(new double[]{i,s.sx,s.sy,ray[0],ray[1],0,len,0,ray.length>4?ray[4]:0,ray[2]});
    }
    ArrayList<double[]> spawned=new ArrayList<double[]>();
    for(int k=pulses.size()-1;k>=0;k--){
      double[] p=pulses.get(k);p[5]+=SimulationSettings.PULSE_SPEED_MM_PER_S*dt;
      if(p[5]<p[6])continue;
      pulses.remove(k);
      if(p[7]==0&&p[9]>0&&random(1)<p[8]){
        Sensor s=model.sensors[(int)p[0]];
        spawned.add(new double[]{p[0],p[3],p[4],s.sx,s.sy,0,Math.hypot(s.sx-p[3],s.sy-p[4]),1,0,0});
      }
    }
    pulses.addAll(spawned);
  }
  for(double[] p:pulses){
    double f=p[6]<=0?1:Math.min(1,p[5]/p[6]),x=p[1]+(p[3]-p[1])*f,y=p[2]+(p[4]-p[2])*f;
    int c=SENSOR_COLOURS[(int)p[0]];
    if(p[7]==0){noStroke();fill(c,150);ellipse(sx(x),sy(y),4,4);}
    else{
      // Returning pulse: brighter, with a short trail back towards the wall.
      double tf=Math.max(0,f-0.25),tx=p[1]+(p[3]-p[1])*tf,ty=p[2]+(p[4]-p[2])*tf;
      stroke(c,120);strokeWeight(2);line(sx(tx),sy(ty),sx(x),sy(y));
      stroke(INK);strokeWeight(1);fill(c);ellipse(sx(x),sy(y),7,7);
    }
  }
}
public float sx(double x){return originX+(float)x*viewScale;}
public float sy(double y){return originY-(float)y*viewScale;}
public double deg(double a){return (Math.toDegrees(a)%360+360)%360;}
public String fmt(double v,int digits){return String.format(Locale.US,"%."+digits+"f",v);}
public boolean enabled(UiButton b){return !b.id.equals("start")||!model.control.active();}
public void drawButton(UiButton b){
  String label=b.label;
  if(b.id.equals("speed"))label="Speed: "+SPEEDS[speedIndex]+"x";
  if(b.id.equals("pause"))label=model.paused?"Resume":"Pause";
  if(b.id.equals("noise"))label="ADC noise: "+(model.noise?"ON":"OFF");
  if(b.id.equals("bias"))label="Motor mismatch: "+(model.motorBias?"ON":"OFF");
  if(b.id.equals("estimates"))label=(showEstimates?"Hide":"Show")+" scan memory [V]";
  if(b.id.equals("irmodel"))label="IR reflection: "+(model.irReflection?"ON":"OFF")+"  [I]";
  boolean on=enabled(b),primary=b.id.equals("start"),hover=b.hit(mouseX,mouseY);
  noStroke();fill(!on?0xffe9edf3:(primary?BLUE:(b.id.equals("stop")?0xffffe5e5:(hover?0xffe4edfb:0xffffffff))));rect(b.x,b.y,b.w,b.h,7);
  fill(!on?0xff9ca8b6:(primary?0xffffffff:(b.id.equals("stop")?0xffb13232:INK)));
  textFont(uiFont);textSize(11);textAlign(CENTER,CENTER);text(label,b.x+b.w/2,b.y+b.h/2-1);textAlign(LEFT,BASELINE);
}
public void clearBatch(){batchActive=false;batchIndex=batchPassed=batchFailed=0;batchRows.clear();}
public void customPose(double x,double y,double angle){
  if(model.control.active())return;
  if(!model.validStart(x,y)){
    toast="Place the robot inside a room or doorway without overlapping a wall.";toastUntil=millis()+8000;return;
  }
  clearBatch();model.seed=0;model.reposition(x,y,angle);toastUntil=0;
}
public void action(String id){
  if(id.equals("pause")){model.paused=!model.paused;return;}
  if(id.equals("speed")){speedIndex=(speedIndex+1)%SPEEDS.length;return;}
  if(id.equals("csv")){saveLogs();return;}
  if(id.equals("estimates")){showEstimates=!showEstimates;return;}
  if(id.equals("stop")){batchActive=false;model.stop();return;}
  if(id.equals("batch")){beginBatch();return;}
  if(id.equals("start")){
    if(!model.control.active()){
      if(model.collided||!model.validStart(model.x,model.y)){
        toast="Choose Reset start or Random start before running again.";toastUntil=millis()+8000;return;
      }
      clearBatch();model.start();toastUntil=0;
    }return;
  }
  if(id.equals("rotateLeft")||id.equals("rotateRight")){
    if(!model.control.active()){
      boolean current=model.validStart(model.x,model.y)&&!model.collided;
      customPose(current?model.x:model.startX,current?model.y:model.startY,(current?model.theta:model.startTheta)+Math.toRadians(id.equals("rotateLeft")?90:-90));
    }return;
  }
  clearBatch();
  if(id.equals("reset"))model.reset();
  if(id.equals("random"))model.randomStart(nextSeed++);
  if(id.equals("centre")){model.seed=0;double[] p=model.map.centre(0);model.newTrial(p[0],p[1],0);}
  if(id.equals("corner")){model.seed=0;double[] p=model.map.corner();model.newTrial(p[0],p[1],Math.toRadians(180));}
  if(id.equals("wall")){model.seed=0;double[] p=model.map.nearWall();model.newTrial(p[0],p[1],0);}
  if(id.equals("opening")){model.seed=0;double[] p=model.map.nearOpening(65);model.newTrial(p[0],p[1],model.map.exitHeading()+Math.PI/2);}
  if(id.equals("noise")){model.noise=!model.noise;model.reset();}
  if(id.equals("bias")){model.motorBias=!model.motorBias;model.reset();}
  if(id.equals("irmodel")){model.irReflection=!model.irReflection;model.reset();}
  if(id.equals("narrow")){model.openingWidth=Math.max(10,model.openingWidth-10);model.reset();}
  if(id.equals("widen")){model.openingWidth=Math.min(model.map.maxGapWidth(),model.openingWidth+10);model.reset();}
  accumulator=0;previousMillis=millis();
}
public void beginBatch(){
  clearBatch();batchRows.add("seed,start_x_mm,start_y_mm,start_theta_deg,opening_mm,noise,motor_bias,sim_seconds,pass,collision,final_state,first_outside_seconds,scans,corners,opening_checks,true_path_mm,reason,map_span_width_mm,map_span_height_mm,exit_side,internal_door_mm,map_revision,start_room,final_x_mm,final_y_mm,final_room,remembered_doors,door_crossings,backtracks,skipped_doors,known_nodes,open_area_candidate,ir_reflection_model");
  batchActive=true;batchIndex=1;model.randomStart(1);model.start();
}
public void finishBatchCase(){
  if(model.success())batchPassed++;else batchFailed++;
  batchRows.add(String.format(Locale.US,"%d,%.4f,%.4f,%.3f,%.1f,%b,%b,%.2f,%b,%b,%d,%.2f,%d,%d,%d,%.3f,\"%s\",%.1f,%.1f,%c,%.1f,%s,%s,%.4f,%.4f,%s,%d,%d,%d,%d,%d,%b,%b",model.seed,model.startX,model.startY,deg(model.startTheta),model.openingWidth,model.noise,model.motorBias,model.now/1000.0,model.success(),model.collided,model.control.state,model.firstOutsideMs<0?-1:model.firstOutsideMs/1000.0,model.control.scans,model.control.corners,model.control.gaps,model.truePathMm,model.control.message.replace("\"","\"\""),model.width,model.height,model.map.side,MapLayout.DOOR_MM,MapLayout.REVISION,model.map.roomName(model.startX,model.startY),model.x,model.y,model.map.roomName(model.x,model.y),model.control.memory.doors.size(),model.control.memory.crossings,model.control.memory.backtracks,model.control.memory.skipped,model.control.memory.knownRooms(),model.control.openAreaCandidate,model.irReflection));
  if(batchIndex>=BATCH_SIZE){batchActive=false;toast="Batch finished. Save CSV to keep the 20-run summary.";toastUntil=millis()+8000;return;}
  batchIndex++;model.randomStart(batchIndex);model.start();
}
public void mousePressed(){
  for(UiButton b:buttons)if(b.hit(mouseX,mouseY)){if(enabled(b))action(b.id);return;}
  if(mouseX>WORLD_X&&mouseX<WORLD_X+WORLD_W&&mouseY>WORLD_Y&&mouseY<WORLD_Y+WORLD_H&&!model.control.active()){
    customPose((mouseX-originX)/viewScale,(originY-mouseY)/viewScale,model.theta);
  }
}
public void keyPressed(){
  if(key==ESC){key=0;action("stop");return;}
  if(key==CODED&&!model.control.active()){
    double d=keyCode==UP?5:(keyCode==DOWN?-5:0),a=keyCode==LEFT?Math.toRadians(90):(keyCode==RIGHT?-Math.toRadians(90):0);
    if(d!=0||a!=0)customPose(model.x+d*Math.cos(model.theta),model.y+d*Math.sin(model.theta),model.theta+a);return;
  }
  char k=Character.toLowerCase(key);
  if(k=='e')action("start");if(k=='s')action("stop");if(k=='r')action("reset");if(k=='n')action("random");
  if(k==' ')action("pause");if(k=='c')action("csv");if(k=='v')action("estimates");
  if(k=='i'&&!model.control.active())action("irmodel");
}
public void saveLogs(){
  try{
    Path folder=Paths.get(sketchPath("logs"));Files.createDirectories(folder);long stamp=System.currentTimeMillis();
    Path path=folder.resolve("sim5_seed"+model.seed+"_"+stamp+".csv");Files.write(path,model.log,StandardCharsets.UTF_8);println("Saved "+path.toAbsolutePath());
    ArrayList<String> events=new ArrayList<String>();
    events.add("sim_ms,state,exploration_node,remembered_doors,door_crossings,backtracks,odom_x_mm,odom_y_mm,note");events.addAll(model.control.events);
    Files.write(folder.resolve("sim5_events_seed"+model.seed+"_"+stamp+".csv"),events,StandardCharsets.UTF_8);
    if(batchRows.size()>1){Path summary=folder.resolve("sim5_batch_"+stamp+".csv");Files.write(summary,batchRows,StandardCharsets.UTF_8);println("Saved "+summary.toAbsolutePath());}
    toast="CSV saved: Sketch > Show Sketch Folder > logs.";
  }catch(Exception e){toast="Could not save CSV: "+e.getMessage();println(toast);}
  toastUntil=millis()+8000;
}
class UiButton{
  String id,label;float x,y,w,h;
  UiButton(String i,String l,float xx,float yy,float ww,float hh){id=i;label=l;x=xx;y=yy;w=ww;h=hh;}
  boolean hit(float px,float py){return px>=x&&px<=x+w&&py>=y&&py<=y+h;}
}
