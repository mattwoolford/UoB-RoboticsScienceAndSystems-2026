/**
 * Exact port of firmware/BoxEscape/TrialRecorder.cpp.
 * Produces the same 25-column CSV schema, 512-row ring buffer, 200 ms sampling,
 * and start/change/sample/finish events as the physical Stamp-C3 robot.
 */
class TrialRecorder_c {
  final int CAPACITY = 512;
  final long PERIOD_MS = 200;

  class Sample {
    long ms;
    String mode, phase, reason, event;
    float x, y, deg;
    int leftTicks, rightTicks;
    int front, left, right;
    int leftPwm, rightPwm;
  }

  private Sample[] ring = new Sample[CAPACITY];
  private int runId = 0;
  private int nextId = 1;
  private int count = 0;
  private String state = "empty"; // empty, active, finished, rejected
  private boolean calAtStart = false;
  private int leftThresh = -1, rightThresh = -1;

  private boolean capturing = false;
  private long started = 0;
  private long lastAt = 0;
  private String lastMode = "", lastPhase = "", lastNote = "";
  String lastSavedPath = "";

  void initNextIdFromLogs(String logsDir) {
    if (logsDir == null) return;
    java.io.File dir = new java.io.File(logsDir);
    if (!dir.exists() || !dir.isDirectory()) return;
    java.io.File[] files = dir.listFiles();
    if (files == null) return;
    int maxId = 0;
    for (int i = 0; i < files.length; i++) {
      String n = files[i].getName();
      if (n.startsWith("box-escape-sim-") && n.endsWith(".csv")) {
        String numPart = n.substring("box-escape-sim-".length(), n.length() - 4);
        try {
          int v = Integer.parseInt(numPart);
          if (v > maxId) maxId = v;
        } catch (Exception ignored) { }
      }
    }
    if (maxId >= nextId) nextId = maxId + 1;
  }

  int currentRunId() { return runId; }
  int sampleCount() { return count < CAPACITY ? count : CAPACITY; }
  boolean hasData() { return count > 0; }
  String runState() { return state; }

  private Sample readCached(Controller_c c, Robot_c r, TopIR_c ir, long now, String event) {
    OdometryModel_c.Pose p = c.odometry().pose;
    Sample s = new Sample();
    s.ms = now - started;
    s.mode = c.modeName();
    s.phase = c.phaseName();
    s.reason = c.note();
    s.event = event;
    s.x = p.x;
    s.y = p.y;
    s.deg = p.theta * 57.2957795f;
    s.leftTicks = r.getLeftEncoderCount();
    s.rightTicks = r.getRightEncoderCount();
    s.front = ir.reading.front;
    s.left = ir.reading.back_left;
    s.right = ir.reading.back_right;
    s.leftPwm = r.getLeftMotorPWM();
    s.rightPwm = r.getRightMotorPWM();
    return s;
  }

  private void remember(Sample row, String nextState, boolean isNewRun) {
    if (isNewRun) {
      runId = nextId++;
      count = 0;
    }
    ring[count % CAPACITY] = row;
    count++;
    state = nextState;
    lastMode = row.mode;
    lastPhase = row.phase;
    lastNote = row.reason;
  }

  void beginEscapeRecord(Controller_c c, Robot_c r, TopIR_c ir, boolean calibrated, int lThresh, int rThresh) {
    started = lastAt = r.getMillis();
    calAtStart = calibrated;
    leftThresh = calibrated ? lThresh : -1;
    rightThresh = calibrated ? rThresh : -1;
    capturing = c.modeName().equals("ESCAPE");
    Sample row = readCached(c, r, ir, started, capturing ? "start" : "rejected");
    remember(row, capturing ? "active" : "rejected", true);
  }

  void observeEscapeRecord(Controller_c c, Robot_c r, TopIR_c ir) {
    if (!capturing) return;
    long now = r.getMillis();
    String mode = c.modeName();
    String phase = c.phaseName();
    String note = c.note();
    boolean changed = !mode.equals(lastMode) || !phase.equals(lastPhase) || !note.equals(lastNote);
    if (!changed && (now - lastAt < PERIOD_MS)) return;
    lastAt = now;
    capturing = mode.equals("ESCAPE");
    String event = !capturing ? "finish" : (changed ? "change" : "sample");
    remember(readCached(c, r, ir, now, event), capturing ? "active" : "finished", false);
  }

  private String csvQuote(String s) {
    if (s == null) return "\"\"";
    return "\"" + s.replace("\"", "\"\"") + "\"";
  }

  String buildCsv() {
    StringBuilder sb = new StringBuilder();
    sb.append("real_ms,mode,phase,front_raw,back_left_raw,back_right_raw,left_pwm,right_pwm,")
      .append("left_ticks,right_ticks,x_mm,y_mm,theta_deg,reason,run_id,trimmed,run_state,event,")
      .append("escape_settings,motor_calibrated_at_start,left_threshold_pwm,right_threshold_pwm,")
      .append("sensor_settings,odometry_settings,pilot_revision\r\n");

    int startIdx = count > CAPACITY ? count - CAPACITY : 0;
    int trimmed = count > CAPACITY ? 1 : 0;
    String escSettings = calAtStart ? "nominal_with_prior_motor_check" : "nominal_no_calibration";
    int calFlag = calAtStart ? 1 : 0;

    for (int i = startIdx; i < count; i++) {
      Sample r = ring[i % CAPACITY];
      sb.append(r.ms).append(',')
        .append(csvQuote(r.mode)).append(',')
        .append(csvQuote(r.phase)).append(',')
        .append(r.front).append(',')
        .append(r.left).append(',')
        .append(r.right).append(',')
        .append(r.leftPwm).append(',')
        .append(r.rightPwm).append(',')
        .append(r.leftTicks).append(',')
        .append(r.rightTicks).append(',')
        .append(String.format(java.util.Locale.US, "%.3f,%.3f,%.3f", r.x, r.y, r.deg)).append(',')
        .append(csvQuote(r.reason)).append(',')
        .append(runId).append(',')
        .append(trimmed).append(',')
        .append(state).append(',')
        .append(r.event).append(',')
        .append(escSettings).append(',')
        .append(calFlag).append(',')
        .append(leftThresh).append(',')
        .append(rightThresh).append(',')
        .append("existing_raw_thresholds,nominal_geometry,opening_retry_v1\r\n");
    }
    return sb.toString();
  }

  String saveToDirectory(String logsDir) {
    if (!hasData() || logsDir == null) return "";
    try {
      java.io.File dir = new java.io.File(logsDir);
      if (!dir.exists()) dir.mkdirs();
      String suffix = state.equals("active") ? "-partial" : "";
      String fname = String.format(java.util.Locale.US, "box-escape-sim-%04d%s.csv", runId, suffix);
      java.io.File out = new java.io.File(dir, fname);
      java.io.OutputStreamWriter w = new java.io.OutputStreamWriter(
        new java.io.FileOutputStream(out), java.nio.charset.StandardCharsets.UTF_8);
      w.write(buildCsv());
      w.close();
      lastSavedPath = out.getAbsolutePath();
      return lastSavedPath;
    } catch (Exception e) {
      return "";
    }
  }
}
