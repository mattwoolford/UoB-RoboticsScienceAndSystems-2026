// sim5 90-degree controller settings. Distances in mm, angles in radians.
final class NavigationSettings {
  static final double BODY_RADIUS_MM=50, SENSOR_RADIUS_MM=50;
  static final double DRIVE_PWM=30, TURN_PWM=65, TURN_FINE_PWM=25;
  static final double HEADING_GAIN=40, ARRIVAL_MM=1.0;

  // Sensor thresholds (raw ADC, lower = closer).
  static final int FRONT_STOP=1950;        // Wall ahead (~30 mm in front of the body): turn left 90.
  static final double RIGHT_TARGET=3000;   // Right wall ~30 mm from the body while following.
  static final int RIGHT_PRESENT=3300, RIGHT_GAP=3500;
  static final int OPEN_RETURN_THRESHOLD=4085;
  static final int SIDE_DANGER=1862;       // A back sensor this strong (~15 mm side gap): steer away.

  // Wall following: small steering while driving (not in-place turns).
  static final double RIGHT_HEADING_GAIN=0.00007; // rad per ADC count of right-wall error.
  static final double MAX_STEER_RAD=0.15;         // Max steering offset from the wall heading (~8.6 deg).
  // Wall alignment while driving: fit the side-gap slope over this much travel
  // and correct the 90-degree reference by the measured angle to the wall.
  static final double ALIGN_WINDOW_MM=120, ALIGN_GAIN=0.7, ALIGN_MAX_RAD=Math.toRadians(15);
  static final double ALIGN_MIN_GAP_MM=8, ALIGN_MAX_GAP_MM=75;
  // Just after a turn the back-right sensor looks back into the corner and
  // over-reads; hold a straight line (no wall steering, no gap checks) this far.
  static final double SETTLE_AFTER_TURN_MM=100;

  // Gaps. The back-right sensor looks backwards, so it notices each gap edge
  // after the robot centre has passed it by about this distance.
  static final double GAP_SENSOR_LAG_MM=80;
  static final double MIN_PASSABLE_GAP_MM=125;    // Body 100 mm + clearance; narrower gaps are passed by.
  static final double GAP_SEARCH_MAX_MM=350;      // No far edge within this: treat as an outside corner.
  static final double CORNER_CLEARANCE_MM=90;     // Robot centre beyond the corner edge before turning right.
  static final double CROSS_CLEAR_MM=280;         // Straight travel after the right turn before looking sideways again.
  static final double CROSS_DOOR_MM=99;           // Approx. distance from turn point to the doorway (for the display).
  static final double LOST_WALL_MM=300;

  static final int COUNTDOWN_MS=1000, RUN_LIMIT_MS=900000;
  static final double TRAVEL_LIMIT_MM=25000;
  // A heuristic, NOT evidence of being outside an arbitrary unknown layout.
  static final double OPEN_PROBE_MM=1000;

  // Used by PassageMemory (doorway bookkeeping shown in the UI).
  static final double DOOR_MATCH_MM=90, DOOR_MATCH_ANGLE=Math.toRadians(30);
  static final double LOOP_MATCH_MM=55, LOOP_MIN_TRAVEL_MM=350;
  static final double RECROSS_COOLDOWN_MM=200;
}
