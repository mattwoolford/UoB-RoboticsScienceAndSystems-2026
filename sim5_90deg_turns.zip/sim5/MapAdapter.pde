// The map picture is now drawn from MapLayout.java's wall rectangles, so the
// display, IR beams and collisions always use exactly the same walls.
// No data/arena_map.png is needed for the single-box layout.
PImage surfaceImage;
double displayedOpening=Double.NaN;

public MapLayout loadMap(){
  MapLayout layout=new MapLayout();
  displayedOpening=Double.NaN;
  return layout;
}

// Redraw whenever the outside exit width changes (the -/+ buttons).
public void updateDisplayedMap(){
  if(displayedOpening==model.openingWidth&&surfaceImage!=null)return;
  PGraphics canvas=createGraphics(model.map.imageWidth,model.map.imageHeight,JAVA2D);
  canvas.beginDraw();canvas.background(255);canvas.noStroke();canvas.fill(0);
  for(double[] r:model.map.wallBlocks(model.openingWidth)){
    canvas.rect((float)model.map.imageX(r[0]),(float)model.map.imageY(r[3]),(float)(r[2]-r[0]),(float)(r[3]-r[1]));
  }
  canvas.endDraw();surfaceImage=canvas.get();canvas.dispose();
  displayedOpening=model.openingWidth;
}
