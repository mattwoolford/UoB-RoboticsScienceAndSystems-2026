import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

// The world is private to the simulator. Navigator receives only Observation.
final class TwinModel {
  final MapLayout map;
  final double width,height;
  double openingWidth,rearAngleDeg=SimulationSettings.REAR_SENSOR_ANGLE_DEG;
  boolean noise=false,motorBias=false,paused=false,collided=false,recording=true;
  boolean irReflection=SimulationSettings.IR_REFLECTION_MODEL;
  long now=0,seed=0,firstOutsideMs=-1;
  double truePathMm=0;
  double x,y,theta,startX,startY,startTheta;
  double odomX,odomY,odomTheta,leftCount,rightCount,oldLeft,oldRight,leftPWM,rightPWM;
  final double mmPerCount=2*Math.PI*SimulationSettings.WHEEL_RADIUS_MM/SimulationSettings.COUNTS_PER_REVOLUTION;
  Navigator control=new Navigator();
  final ArrayList<Wall> walls=new ArrayList<Wall>();
  final ArrayList<double[]> trail=new ArrayList<double[]>();
  final ArrayList<String> log=new ArrayList<String>();
  final Sensor[] sensors={new Sensor("A_G0",1),new Sensor("A_G1",0),new Sensor("A_G4",-1)};
  Random rng=new Random(SimulationSettings.NOISE_SEED);
  String notice="Choose a start, then run the escape test.";
  TwinModel(MapLayout layout){map=layout;width=map.spanWidth;height=map.spanHeight;openingWidth=map.gapWidth;double[] p=map.centre(0);newTrial(p[0],p[1],0);}
  double gapStart(){return map.gapStart(openingWidth);}
  double gapEnd(){return map.gapEnd(openingWidth);}
  void buildWalls(){
    map.buildWalls(walls,openingWidth);
  }
  boolean validStart(double px,double py){
    return Double.isFinite(px)&&Double.isFinite(py)&&map.insideStartBoundary(px,py,SimulationSettings.BODY_RADIUS_MM,openingWidth)&&!overlapsWall(px,py);
  }
  boolean newTrial(double px,double py,double angle){
    buildWalls();
    if(!validStart(px,py)){notice="Place the robot inside a room or doorway without overlapping a wall.";return false;}
    x=startX=px;y=startY=py;theta=startTheta=angle;
    odomX=odomY=odomTheta=leftCount=rightCount=oldLeft=oldRight=leftPWM=rightPWM=0;
    now=0;firstOutsideMs=-1;truePathMm=0;collided=paused=false;control=new Navigator();rng=new Random(SimulationSettings.NOISE_SEED);
    trail.clear();log.clear();
    log.add("experiment,seed,sim_ms,state,A_G0,A_G1,A_G4,pwm_left,pwm_right,encoder_left,encoder_right,true_x_mm,true_y_mm,true_theta_rad,odom_x_mm,odom_y_mm,odom_theta_rad,collision,fully_outside,noise,motor_bias,opening_mm,start_x_mm,start_y_mm,start_theta_rad,scans,corners,opening_checks,first_outside_ms,true_path_mm,map_span_width_mm,map_span_height_mm,exit_side,internal_door_mm,map_revision,start_room,remembered_doors,door_crossings,backtracks,skipped_doors,exploration_node,open_area_candidate,ir_reflection_model,A_G0_indirect_share,A_G1_indirect_share,A_G4_indirect_share,A_G0_scatter_share,A_G1_scatter_share,A_G4_scatter_share");
    sampleSensors();record();trail.add(new double[]{x,y});notice="Starting pose set. Ready to run.";return true;
  }
  void reset(){newTrial(startX,startY,startTheta);}
  void randomStart(long value){
    seed=value;Random random=new Random(seed*0x9E3779B97F4A7C15L+0x632BE59BD9B4E019L);double r=SimulationSettings.BODY_RADIUS_MM+3;
    // Rejection sampling keeps starts out of exterior white space and shared walls.
    buildWalls();
    for(int attempt=0;attempt<10000;attempt++){
      // The 90-degree controller assumes a square start: snap to 0/90/180/270 deg.
      double px=r+random.nextDouble()*(width-2*r),py=r+random.nextDouble()*(height-2*r),angle=Math.floor(random.nextDouble()*4)*Math.PI/2;
      if(!validStart(px,py))continue;
      boolean clear=true;for(Wall wall:walls)if(wall.distance(px,py)<r){clear=false;break;}
      if(clear){newTrial(px,py,angle);return;}
    }
    throw new IllegalStateException("No valid starting pose found for seed "+seed);
  }
  boolean reposition(double px,double py,double angle){
    if(control.active()){notice="Stop the controller before setting a new starting pose.";return false;}
    return newTrial(px,py,angle);
  }
  boolean start(){
    if(control.active())return false;
    if(collided||!validStart(x,y)){notice="Reset to an interior starting pose first.";return false;}
    // Each trial's odometry origin is the unknown starting pose, not world coordinates.
    newTrial(x,y,theta);paused=false;boolean ok=control.start(observation());notice=control.message;return ok;
  }
  void stop(){
    if(control.state==Navigator.DONE||control.state==Navigator.STOPPED)return;
    control.stop("Stopped by you.");leftPWM=rightPWM=0;paused=false;notice=control.message;record();
  }
  Observation observation(){
    Observation o=new Observation();o.now=now;o.left=sensors[0].reading;o.front=sensors[1].reading;o.right=sensors[2].reading;
    o.x=odomX;o.y=odomY;o.theta=odomTheta;return o;
  }
  void step(){
    // Keep the final time and result stable after a run finishes or is stopped.
    if(paused||control.state==Navigator.DONE||control.state==Navigator.STOPPED)return;
    now+=SimulationSettings.PHYSICS_STEP_MS;
    if(now%SimulationSettings.CONTROL_STEP_MS==0){
      double l=Math.round(leftCount),r=Math.round(rightCount),dl=(l-oldLeft)*mmPerCount,dr=(r-oldRight)*mmPerCount;
      oldLeft=l;oldRight=r;double ds=(dl+dr)/2;
      odomX+=ds*Math.cos(odomTheta);odomY+=ds*Math.sin(odomTheta);odomTheta+=(dr-dl)/SimulationSettings.WHEEL_SEPARATION_MM;
      sampleSensors();control.update(observation());leftPWM=control.leftPWM;rightPWM=control.rightPWM;
    }
    physics(SimulationSettings.PHYSICS_STEP_MS);
    if(firstOutsideMs<0&&fullyOutside())firstOutsideMs=now;
    if(recording&&now%SimulationSettings.LOG_PERIOD_MS==0){record();if(trail.size()<16000)trail.add(new double[]{x,y});}
    else if(recording&&(control.state==Navigator.DONE||control.state==Navigator.STOPPED)){record();if(trail.size()<16000)trail.add(new double[]{x,y});}
  }
  void physics(int dt){
    double dl=limit(leftPWM,-200,200)/200*SimulationSettings.MAX_WHEEL_SPEED_MM_PER_MS*dt;
    double dr=limit(rightPWM,-200,200)/200*SimulationSettings.MAX_WHEEL_SPEED_MM_PER_MS*dt;
    if(motorBias)dr*=SimulationSettings.RIGHT_MOTOR_BIAS;
    double ds=(dl+dr)/2,da=(dr-dl)/SimulationSettings.WHEEL_SEPARATION_MM;
    double arc=Math.abs(da)<1e-9?1:Math.sin(da/2)/(da/2);
    double nx=x+ds*arc*Math.cos(theta+da/2),ny=y+ds*arc*Math.sin(theta+da/2);
    if((Math.abs(dl)+Math.abs(dr)>0)&&overlapsWall(nx,ny)){
      collided=true;control.stop("Collision with a wall or door edge.");leftPWM=rightPWM=0;notice=control.message;record();return;
    }
    truePathMm+=Math.abs(ds);x=nx;y=ny;theta+=da;leftCount+=dl/mmPerCount;rightCount+=dr/mmPerCount;
  }
  boolean overlapsWall(double px,double py){for(Wall w:walls)if(w.distance(px,py)<SimulationSettings.BODY_RADIUS_MM-1e-7)return true;return false;}
  boolean fullyOutside(){return !collided&&map.fullyOutside(x,y,SimulationSettings.BODY_RADIUS_MM);}
  boolean success(){return control.state==Navigator.DONE&&fullyOutside()&&!collided;}
  String outcome(){
    if(collided)return "COLLISION";
    if(control.state==Navigator.DONE)return success()?"PASS - simulator confirms body outside":"FAIL - tentative stop while still inside";
    if(control.state==Navigator.STOPPED)return "STOPPED - see reason below";
    return control.active()?(fullyOutside()?"Body outside; controller still running":"Searching for the exit"):"Ready for an interior starting pose";
  }
  double worldX(double ox,double oy){return startX+ox*Math.cos(startTheta)-oy*Math.sin(startTheta);}
  double worldY(double ox,double oy){return startY+ox*Math.sin(startTheta)+oy*Math.cos(startTheta);}
  void sampleSensors(){for(Sensor s:sensors)s.sample(this);}
  void record(){
    if(!recording||log.size()>16001)return;
    log.add(String.format(Locale.US,"sim5,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%d,%d,%.4f,%.4f,%.6f,%.4f,%.4f,%.6f,%b,%b,%b,%b,%.1f,%.3f,%.3f,%.6f,%d,%d,%d,%d,%.3f,%.1f,%.1f,%c,%.1f,%s,%s,%d,%d,%d,%d,%d,%b,%b,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f",
      seed,now,control.state,sensors[0].reading,sensors[1].reading,sensors[2].reading,leftPWM,rightPWM,Math.round(leftCount),Math.round(rightCount),x,y,theta,odomX,odomY,odomTheta,collided,fullyOutside(),noise,motorBias,openingWidth,startX,startY,startTheta,control.scans,control.corners,control.gaps,firstOutsideMs,truePathMm,width,height,map.side,MapLayout.DOOR_MM,MapLayout.REVISION,map.roomName(startX,startY),control.memory.doors.size(),control.memory.crossings,control.memory.backtracks,control.memory.skipped,control.memory.current,control.openAreaCandidate,irReflection,sensors[0].indirectShare,sensors[1].indirectShare,sensors[2].indirectShare,sensors[0].scatterShare,sensors[1].scatterShare,sensors[2].scatterShare));
  }
  static double limit(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
  static double frontReading(double distance){
    double[] d={5,10,50,100,SimulationSettings.IR_MAX_RANGE_MM},a={260,390,3500,4085,4095};
    if(!Double.isFinite(distance)||distance>=d[4])return 4095;if(distance<=d[0])return a[0];
    for(int i=1;i<d.length;i++)if(distance<=d[i])return a[i-1]+(a[i]-a[i-1])*(distance-d[i-1])/(d[i]-d[i-1]);return 4095;
  }
}

final class Wall {
  final double ax,ay,bx,by;
  Wall(double a,double b,double c,double d){ax=a;ay=b;bx=c;by=d;}
  double distance(double x,double y){double dx=bx-ax,dy=by-ay,u=TwinModel.limit(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0,1);return Math.hypot(x-ax-u*dx,y-ay-u*dy);}
  double ray(double x,double y,double dx,double dy){
    double sx=bx-ax,sy=by-ay,den=dx*sy-dy*sx;if(Math.abs(den)<1e-12)return Double.POSITIVE_INFINITY;
    double qx=ax-x,qy=ay-y,t=(qx*sy-qy*sx)/den,u=(qx*dy-qy*dx)/den;
    return t>=0&&u>=0&&u<=1?t:Double.POSITIVE_INFINITY;
  }
}

final class Sensor {
  final String name;final int side;int reading=4095;double sx,sy,heading;
  // rays: {end x, end y, hit 0/1, beam weight 0..1}. bounces: {wall 1 x, y, wall 2 x, y, light}.
  final ArrayList<double[]> rays=new ArrayList<double[]>();
  final ArrayList<double[]> bounces=new ArrayList<double[]>();
  // scatter: diffuse-scattering paths {wall 1 x, y, wall 2 x, y, light}.
  final ArrayList<double[]> scatter=new ArrayList<double[]>();
  double indirectShare=0,scatterShare=0,directLight=0,indirectLight=0;
  Sensor(String n,int s){name=n;side=s;}
  void sample(TwinModel m){
    double angle=side*Math.toRadians(m.rearAngleDeg);heading=m.theta+angle;
    sx=m.x+SimulationSettings.SENSOR_RADIUS_MM*Math.cos(heading);sy=m.y+SimulationSettings.SENSOR_RADIUS_MM*Math.sin(heading);
    rays.clear();bounces.clear();scatter.clear();indirectShare=scatterShare=directLight=indirectLight=0;
    if(m.irReflection){
      double raw=IRReflection.reading(this,m);
      if(m.noise&&raw<4095-0.001)raw+=(m.rng.nextDouble()*2-1)*SimulationSettings.NOISE_AMPLITUDE;
      reading=(int)Math.round(TwinModel.limit(raw,0,4095));return;
    }
    // Original sim5 model (press I to compare): straight rays, no reflection physics.
    double half=Math.toRadians(side==0?SimulationSettings.FRONT_HALF_BEAM_DEG:SimulationSettings.REAR_HALF_BEAM_DEG);
    double strength=0,totalWeight=0;
    for(int i=0;i<SimulationSettings.BEAM_RAYS;i++){
      double fraction=2.0*i/(SimulationSettings.BEAM_RAYS-1)-1,offset=half*fraction,dx=Math.cos(heading+offset),dy=Math.sin(heading+offset),nearest=Double.POSITIVE_INFINITY;
      for(Wall w:m.walls)nearest=Math.min(nearest,w.ray(sx,sy,dx,dy));
      double axial=nearest*Math.cos(offset);boolean hit=axial<SimulationSettings.IR_MAX_RANGE_MM;
      double length=hit?nearest:SimulationSettings.IR_MAX_RANGE_MM/Math.cos(offset);
      if(m.recording)rays.add(new double[]{sx+length*dx,sy+length*dy,hit?1:0,1});
      double weight=1-0.5*Math.abs(fraction);strength+=weight*(4095-TwinModel.frontReading(axial));totalWeight+=weight;
    }
    strength=strength/totalWeight*(side==0?1:SimulationSettings.REAR_RESPONSE_GAIN);double raw=4095-strength;
    if(m.noise&&strength>0.001)raw+=(m.rng.nextDouble()*2-1)*SimulationSettings.NOISE_AMPLITUDE;
    reading=(int)Math.round(TwinModel.limit(raw,0,4095));
  }
}
