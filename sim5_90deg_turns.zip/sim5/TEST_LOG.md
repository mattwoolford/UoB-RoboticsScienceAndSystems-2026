# sim5 test log

The corrected sim4 layout and physical model are unchanged. All runs below use 150 mm internal doors and a 185 mm outside exit.

| Date | Test | Settings | Result |
|---|---|---|---|
| 2026-10-20 | Same 20 starts as sim4 | Noise/mismatch off; doorway memory and continued exploration | **20/20 escapes**, 0 collisions; sim4: 1/20 |
| 2026-10-20 | 24 additional poses | Centres at four headings and four corner starts in each room | **24/24 escapes**, 0 collisions |
| 2026-10-20 | Seeds 1, 4, 5, 20 | ADC noise and motor mismatch both on | **4/4 escapes**, 0 collisions |
| 2026-11-16 | Single box, bottom exit (map `single_box_bottom_exit`) | Same 20 random seeds + 4 presets; headless Java harness, no Processing window | **24/24 escapes**, 0 collisions; also 24/24 with ADC noise and motor mismatch on |
| 2026-11-16 | Single box + IR reflection/diffusion model ON | Same 20 seeds + 4 presets, headless Java | **24/24 escapes**, 0 collisions; 24/24 with noise + mismatch; model OFF reproduces the earlier single-box times exactly |
| 2026-11-16 | Sensitivity, model ON | Mirror fraction 0.35 / front beam sigma 15 deg / rear beam sigma 20 deg | 24/24 / **17/24** (door-edge collisions while crossing) / 23/24 |
| 2026-11-17 | + diffuse scattering between box sides | Same 20 seeds + 4 presets, headless Java | **24/24**, 0 collisions; 24/24 with noise + mismatch; 24/24 with scatter fraction 1.0 and mirror 0.35; OFF still 24/24 |
| 2026-11-17 | Wall albedo 0.65, mirror fraction 0.05, pulse animation | Same 20 seeds + 4 presets, headless Java | **24/24**, 0 collisions; 24/24 with noise + mismatch; calibration points unchanged (60 mm head-on 3617, 30 mm side gap 3000) |
| 2026-11-20 | 90-degree controller (no spinning), IR reflection model ON | 20 seeds (square headings) + 4 presets, headless Java | **24/24**, 0 collisions; every in-place turn ends within 4 deg of the wall grid; gap crossed within 6 mm of centre |
| 2026-11-20 | Same, noise + motor mismatch | as above | **24/24** |
| 2026-11-20 | Same, start tilted +/-3, 5, 10 deg off square | as above | **24/24, 23/24, 13/24**; 10 deg fails as the back-facing side sensors notice a converging wall too late |

Seventeen default trials backtracked deliberately. All successful stops are scored by the simulator; the controller's own open-space conclusion remains tentative.

See `results/` for every result, selected traces and controller events. These tests used headless Processing rendering, not hardware.

For later trials record the commit, tester/date, start pose/seed, map revision, gap width, noise/mismatch settings, outcome and CSV filename. Keep altered layouts/settings in separate result sets.
