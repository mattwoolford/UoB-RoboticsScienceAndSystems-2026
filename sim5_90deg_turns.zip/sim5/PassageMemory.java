import java.util.ArrayList;

// Small exploration graph in the controller's relative odometry frame.
// No map dimensions, world coordinates, room polygons or outside flag.
final class PassageMemory {
  static final class Room {
    final int id;
    int parentDoor=-1;
    int mergedInto=-1;
    boolean exhausted=false,boundaryComplete=false,anchorSet=false;
    double anchorX,anchorY,anchorHeading,followDistance;
    Room(int id){this.id=id;}
    void beginVisit(){anchorSet=false;boundaryComplete=false;followDistance=0;}
  }
  static final class Door {
    final int id;
    double x,y,nx,ny;
    int roomA,roomB,crossings=0;
    Door(int id,double x,double y,double heading,int a,int b){
      this.id=id;this.x=x;this.y=y;nx=Math.cos(heading);ny=Math.sin(heading);roomA=a;roomB=b;
    }
    int other(int room){return room==roomA?roomB:room==roomB?roomA:-1;}
  }
  final ArrayList<Room> rooms=new ArrayList<Room>();
  final ArrayList<Door> doors=new ArrayList<Door>();
  int current=0,lastDoor=-1,crossings=0,backtracks=0,skipped=0;
  double lastCrossPath=-1e9;
  PassageMemory(){rooms.add(new Room(0));}
  Room room(){return rooms.get(current);}
  Door match(double x,double y,double heading){
    Door best=null;double distance=NavigationSettings.DOOR_MATCH_MM;
    for(Door d:doors){
      double alignment=Math.abs(d.nx*Math.cos(heading)+d.ny*Math.sin(heading));
      double e=Math.hypot(x-d.x,y-d.y);
      if(alignment>=Math.cos(NavigationSettings.DOOR_MATCH_ANGLE)&&e<distance){best=d;distance=e;}
    }
    return best;
  }
  boolean childrenDone(){
    for(Door d:doors){
      int next=d.other(current);
      if(next>=0&&next!=current&&d.id!=room().parentDoor&&!rooms.get(next).exhausted&&d.crossings<2)return false;
    }
    return true;
  }
  void follow(double x,double y,double heading,double travelled){
    Room r=room();
    if(!r.anchorSet){r.anchorSet=true;r.anchorX=x;r.anchorY=y;r.anchorHeading=heading;r.followDistance=0;return;}
    r.followDistance+=travelled;
    if(r.followDistance>=NavigationSettings.LOOP_MIN_TRAVEL_MM&&Math.hypot(x-r.anchorX,y-r.anchorY)<=NavigationSettings.LOOP_MATCH_MM&&Math.abs(Navigator.wrap(heading-r.anchorHeading))<0.35)
      r.boundaryComplete=true;
    if(r.boundaryComplete&&childrenDone())r.exhausted=true;
  }
  boolean shouldCross(Door d,double path){
    if(d==null)return true;
    if(d.id==lastDoor&&path-lastCrossPath<NavigationSettings.RECROSS_COOLDOWN_MM)return false;
    int other=d.other(current);
    if(other<0||other==current)return false;
    if(d.id==room().parentDoor)return room().exhausted;
    return !rooms.get(other).exhausted&&d.crossings<2;
  }
  // Re-observing a known doorway from a separately discovered region can
  // close a loop in the exploration graph. Resolve the observed side using
  // the crossing direction, and join the two provisional room nodes.
  void reconcileSide(Door d,double heading){
    if(d==null)return;
    int expected=d.nx*Math.cos(heading)+d.ny*Math.sin(heading)>=0?d.roomA:d.roomB;
    if(expected==current)return;
    int old=current;
    for(Door e:doors){if(e.roomA==old)e.roomA=expected;if(e.roomB==old)e.roomB=expected;}
    rooms.get(old).mergedInto=expected;current=expected;room().beginVisit();
    room().exhausted=false;
  }
  int knownRooms(){int count=0;for(Room r:rooms)if(r.mergedInto<0)count++;return count;}
  Door prepare(double x,double y,double heading){
    Door d=match(x,y,heading);
    if(d==null){
      int next=rooms.size();Room child=new Room(next);rooms.add(child);
      d=new Door(doors.size(),x,y,heading,current,next);doors.add(d);child.parentDoor=d.id;
    }
    return d;
  }
  void crossed(Door d,double path){
    int next=d.other(current);
    if(next<0)throw new IllegalStateException("Passage is not connected to current exploration node.");
    if(d.id==room().parentDoor)backtracks++;
    d.crossings++;crossings++;lastDoor=d.id;lastCrossPath=path;
    current=next;room().beginVisit();
  }
}
