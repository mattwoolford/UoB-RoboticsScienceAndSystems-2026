// Model assumptions, not measured specifications. Units are millimetres and radians.
// Edit a value, then press Run in Processing to rebuild the simulation.
final class SimulationSettings {
  static final double BOX_WIDTH_MM = 400;
  static final double BOX_LENGTH_MM = 350;
  static final double BODY_RADIUS_MM = 50;  // Course twin's drawing radius, now a collision circle.
  static final double OPENING_WIDTH_MM = 200; // Assumes 50 mm clearance on EACH side of 100 mm body.
  static final double WHEEL_RADIUS_MM = 16;
  static final double WHEEL_SEPARATION_MM = 90;
  static final double COUNTS_PER_REVOLUTION = 358.3;
  static final double MAX_WHEEL_SPEED_MM_PER_MS = 0.25; // Original course model at PWM 200.
  static final double SENSOR_RADIUS_MM = 50;
  static final double REAR_SENSOR_ANGLE_DEG = 135; // Back-left +135; back-right -135.
  static final double FRONT_HALF_BEAM_DEG = 15;
  static final double REAR_HALF_BEAM_DEG = 25;
  static final int BEAM_RAYS = 9;
  static final double IR_MAX_RANGE_MM = 120; // Unmeasured cutoff; deliberately editable.
  static final double REAR_RESPONSE_GAIN = 2.437; // Approximate fit at 30 mm body-to-side-wall gap.
  static final int NOISE_AMPLITUDE = 8;  // Optional uniform +/- ADC counts; not a measured distribution.
  static final long NOISE_SEED = 7;
  static final double RIGHT_MOTOR_BIAS = 0.95; // Optional 5% slower right motor.
  static final int PHYSICS_STEP_MS = 10; // Course twin's original fixed step.
  static final int CONTROL_STEP_MS = 20; // Physical Box_Escape_Test controller period.
  static final int LOG_PERIOD_MS = 100;

  // ---- IR reflection + diffusion model (IRReflection.java) ----
  // All values below are model assumptions, NOT measurements. Edit and re-run.
  static final boolean IR_REFLECTION_MODEL = true; // Start-up default; press I in the sim to toggle.
  static final double FRONT_DIFFUSION_SIGMA_DEG = 7.5;  // Beam spread (Gaussian sigma). +/-2 sigma = old 15 deg half-beam.
  static final double REAR_DIFFUSION_SIGMA_DEG = 12.5;  // +/-2 sigma = old 25 deg half-beam.
  static final double DIFFUSION_SPAN_SIGMA = 2.5;       // Rays cover +/-2.5 sigma of the beam.
  static final int DIFFUSION_RAYS = 31;
  static final double WALL_ALBEDO = 0.65;              // Share of IR a box side reflects at all (matte cardboard ~0.5-0.75).
  static final double WALL_MIRROR_FRACTION = 0.05;     // Of the reflected light, share that is mirror-like (matte: a few %).
  static final boolean IR_MULTIPATH = true;            // Second reflection between box sides (master switch).
  static final boolean IR_DIFFUSE_SCATTER = true;      // Matte walls scatter light onto the other sides too.
  static final int SCATTER_RAYS = 12;                   // Scattered directions traced from each lit spot.
  static final double SCATTER_IN_PLANE_FRACTION = 0.5;  // Share of scattered light that stays at sensor height
                                                        // (the rest goes up or into the floor).
  // Rear-sensor sensitivity, solved so a wall 30 mm from the body on the robot's side reads 3000
  // (the controller's RIGHT_TARGET), matching the original sim5 rear calibration point.
  static final double REAR_IR_GAIN = 2.777;
  // Animation only (does not change readings): IR pulses travel along the beam
  // and occasionally return into the sensor.
  static final double RETURN_PULSE_REFERENCE_MM = 30;  // Distance at which a head-on matte wall returns ~65% x beam weight.
  static final double RETURN_PULSE_MAX_CHANCE = 0.6;   // Cap on the chance a single pulse returns.
  static final double PULSES_PER_SECOND = 7;           // Pulses emitted per sensor per real second.
  static final double PULSE_SPEED_MM_PER_S = 220;      // Drawn speed (real IR is light-speed; slowed so it is visible).
}
