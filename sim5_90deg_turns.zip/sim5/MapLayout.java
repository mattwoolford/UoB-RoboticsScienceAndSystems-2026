import java.util.ArrayList;

// Environment geometry only. Navigator never receives this object.
// SINGLE BOX: the original sim5 "main" room on its own. Its left doorway is
// closed, and its bottom doorway is now the ONLY opening and leads outside.
// Measurements: the same reference ArenaMap.pde values used by sim4/sim5.
// Robot behaviour, sensor response and physics remain the sim5 implementation.
final class MapLayout {
  static final String REVISION="single_box_bottom_exit";
  static final double SCALE=1.3, WALL_MM=19, MARGIN_MM=40, DOOR_MM=150;
  // Wall centre line before scaling: x, y DOWN, width, height (old "main" room).
  static final double[] MEASURED_ROOM={180,0,550,385};
  // Old bottom doorway: centre x (unscaled, y-down drawing coordinates).
  static final double MEASURED_EXIT_CENTRE_X=381;
  static final String[] ROOM_NAMES={"box"};
  // World frame: box's left wall centre line is x = 0, bottom wall centre line is y = 0.
  final double spanWidth=MEASURED_ROOM[2]*SCALE,spanHeight=MEASURED_ROOM[3]*SCALE;
  final int imageWidth=(int)Math.ceil(spanWidth+2*MARGIN_MM);
  final int imageHeight=(int)Math.ceil(spanHeight+2*MARGIN_MM);
  // Default exit width: 150 mm, as drawn (same as the old internal doorway).
  // The sim's -/+ buttons still change it between trials.
  final double gapWidth=DOOR_MM;
  final char side='B';
  // Room centre-line rectangle: min x, min y, max x, max y in world mm.
  final double[][] rooms={{0,0,spanWidth,spanHeight}};

  MapLayout(){}
  double worldX(double imageX){return imageX-MARGIN_MM;}
  double worldY(double imageY){return spanHeight+MARGIN_MM-imageY;}
  double imageX(double worldX){return worldX+MARGIN_MM;}
  double imageY(double worldY){return spanHeight+MARGIN_MM-worldY;}
  // The exit runs along the bottom wall, so "along" is an x coordinate.
  double gapCentre(){return (MEASURED_EXIT_CENTRE_X-MEASURED_ROOM[0])*SCALE;}
  double gapStart(double width){return gapCentre()-width/2;}
  double gapEnd(double width){return gapCentre()+width/2;}
  double exitHeading(){return -Math.PI/2;}           // Leaving the box means heading -y.
  double exitX(double along){return along;}
  double exitY(double along){return -WALL_MM/2;}      // Outer face of the bottom wall.
  double[] nearOpening(double inset){return new double[]{gapCentre(),exitY(0)+WALL_MM+inset};}
  // Keep at least one wall thickness of solid wall at each end of the bottom wall.
  double maxGapWidth(){return 2*Math.min(gapCentre(),spanWidth-gapCentre())-2*WALL_MM;}
  double[] centre(int room){double[] r=rooms[room];return new double[]{(r[0]+r[2])/2,(r[1]+r[3])/2};}
  double[] corner(){double[] r=rooms[0];return new double[]{r[0]+WALL_MM/2+53,r[1]+WALL_MM/2+53};}
  double[] nearWall(){double[] r=rooms[0];return new double[]{r[2]-WALL_MM/2-60,(r[1]+r[3])/2};}
  int roomAt(double x,double y){
    for(int i=0;i<rooms.length;i++){
      double[] r=rooms[i];if(x>=r[0]&&x<=r[2]&&y>=r[1]&&y<=r[3])return i;
    }
    return -1;
  }
  String roomName(double x,double y){int i=roomAt(x,y);return i<0?"outside":ROOM_NAMES[i];}

  boolean insideStartBoundary(double x,double y,double radius,double opening){
    if(roomAt(x,y)<0)return false;
    // Close the exit gap ONLY for placement validation: a trial must begin
    // with the whole body inside. This line is never an IR/collision wall.
    double dx=Math.max(0,Math.max(gapStart(opening)-x,x-gapEnd(opening)));
    return Math.hypot(dx,y-(exitY(0)+WALL_MM))>=radius-1e-7;
  }

  boolean fullyOutside(double x,double y,double radius){
    // The whole body must be below the bottom wall's outer face...
    if(y+radius>exitY(0))return false;
    // ...and clear of the box walls.
    for(double[] r:rooms){
      double dx=Math.max(0,Math.max(r[0]-WALL_MM/2-x,x-r[2]-WALL_MM/2));
      double dy=Math.max(0,Math.max(r[1]-WALL_MM/2-y,y-r[3]-WALL_MM/2));
      if(Math.hypot(dx,dy)<radius-1e-7)return false;
    }
    return true;
  }

  // Build the four solid wall rectangles, then subtract the exit rectangle.
  // The same rectangles drive drawing, IR wall segments and collisions.
  ArrayList<double[]> wallBlocks(double outsideWidth){
    if(!Double.isFinite(outsideWidth)||outsideWidth<1||outsideWidth>maxGapWidth())
      throw new IllegalArgumentException("Outside exit width is out of range.");
    double h=WALL_MM/2;
    ArrayList<double[]> blocks=new ArrayList<double[]>();
    for(double[] r:rooms){
      blocks.add(new double[]{r[0]-h,r[1]-h,r[2]+h,r[1]+h});
      blocks.add(new double[]{r[0]-h,r[3]-h,r[2]+h,r[3]+h});
      blocks.add(new double[]{r[0]-h,r[1]-h,r[0]+h,r[3]+h});
      blocks.add(new double[]{r[2]-h,r[1]-h,r[2]+h,r[3]+h});
    }
    double across=h+2;
    double[] cut={gapStart(outsideWidth),rooms[0][1]-across,gapEnd(outsideWidth),rooms[0][1]+across};
    ArrayList<double[]> next=new ArrayList<double[]>();
    for(double[] r:blocks)subtract(r,cut,next);
    return next;
  }
  static void subtract(double[] r,double[] cut,ArrayList<double[]> out){
    double l=Math.max(r[0],cut[0]),b=Math.max(r[1],cut[1]);
    double right=Math.min(r[2],cut[2]),t=Math.min(r[3],cut[3]);
    if(l>=right||b>=t){out.add(r);return;}
    add(out,r[0],r[1],l,r[3]);add(out,right,r[1],r[2],r[3]);
    add(out,l,r[1],right,b);add(out,l,t,right,r[3]);
  }
  static void add(ArrayList<double[]> out,double l,double b,double r,double t){
    if(r>l&&t>b)out.add(new double[]{l,b,r,t});
  }
  void buildWalls(ArrayList<Wall> walls,double opening){
    walls.clear();
    for(double[] r:wallBlocks(opening)){
      walls.add(new Wall(r[0],r[1],r[2],r[1]));walls.add(new Wall(r[2],r[1],r[2],r[3]));
      walls.add(new Wall(r[2],r[3],r[0],r[3]));walls.add(new Wall(r[0],r[3],r[0],r[1]));
    }
  }
}
