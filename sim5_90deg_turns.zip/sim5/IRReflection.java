import java.util.ArrayList;

// IR reflection and beam-diffusion model for the three upper IR sensors.
//
// Each sensor is a co-located emitter + receiver. For every simulated ray:
//
//  1. DIFFUSION: the emitter spreads its light in a cone. Ray strength falls
//     off with angle a from the sensor axis as a Gaussian, E(a). The receiver
//     has the same angular sensitivity, R(a). (sigma set per sensor.)
//
//  2. DIRECT REFLECTION from a box side: the ray hits a wall at distance r and
//     incidence angle i. A mostly diffuse (Lambertian, e.g. cardboard) wall
//     returns   E(a) * R(a) * (1 - m) * cos(i) / r^2
//     so a wall that is far away OR hit at a glancing angle returns less light.
//
//  3. SECOND REFLECTION (multipath) between box sides: a fraction m of the
//     light leaving the first wall is mirror-reflected onto another wall. The
//     second wall scatters it diffusely; the part that can see the receiver
//     returns   E(a) * m * (1 - m) * cos(i2) * R(b) / r3^2
//     where b is the angle the receiver sees that second spot at and r3 is
//     its distance. This makes corners read stronger than a flat wall.
//
//  4. DIFFUSE SCATTERING between box sides: the matte part (1 - m) of the first
//     spot also scatters light in every direction (Lambertian: cos(phi) from
//     the wall normal). Each scattered ray that lands on another side is
//     scattered again, and the part that reaches the receiver adds
//     E(a) * (1 - m) * s(phi) * (1 - m) * cos(i2) * R(b) / r3^2
//     where s(phi) is that ray's share of the scattered light. This spreads a
//     faint glow of IR around the inside of the box.
//
// WALL REFLECTANCE: a box side returns only WALL_ALBEDO of the light reaching
// it (matte brown cardboard in near-IR: roughly 0.5-0.75); the rest is
// absorbed. Only WALL_MIRROR_FRACTION of the returned light is mirror-like
// (matte surfaces: a few percent). Every extra bounce loses light again, so
// wall-to-wall light stays a small part of what reaches a sensor.
//
// CALIBRATION: the summed light I is turned into an ADC reading through the
// existing measured-style curve TwinModel.frontReading(). For a flat wall
// straight in front of the sensor at distance d, I = C / d^2 exactly (C is the
// beam constant below), so that case reproduces the old curve. Every other
// geometry (oblique walls, corners, door edges) now follows the physics above.
// m, the beam widths and the rear gain are model assumptions, not measurements.
final class IRReflection {
  static final class Hit { double t, nx, ny; Wall wall; }

  static double pattern(double angle, double sigma){
    return Math.exp(-angle*angle/(2*sigma*sigma));
  }

  // Nearest wall hit along a ray, ignoring one wall (the one the ray leaves).
  static Hit trace(ArrayList<Wall> walls,double x,double y,double dx,double dy,Wall skip){
    Hit best=null;
    for(Wall w:walls){
      if(w==skip)continue;
      double t=w.ray(x,y,dx,dy);
      if(t>1e-6&&t<Double.POSITIVE_INFINITY&&(best==null||t<best.t)){
        if(best==null)best=new Hit();
        best.t=t;best.wall=w;
      }
    }
    if(best!=null){
      double ex=best.wall.bx-best.wall.ax,ey=best.wall.by-best.wall.ay,len=Math.hypot(ex,ey);
      best.nx=-ey/len;best.ny=ex/len;
    }
    return best;
  }

  static double albedoDiffuse(){return SimulationSettings.WALL_ALBEDO*(1-SimulationSettings.WALL_MIRROR_FRACTION);}
  static double albedoMirror(){return SimulationSettings.WALL_ALBEDO*SimulationSettings.WALL_MIRROR_FRACTION;}

  static double sigma(Sensor s){
    return Math.toRadians(s.side==0?SimulationSettings.FRONT_DIFFUSION_SIGMA_DEG:SimulationSettings.REAR_DIFFUSION_SIGMA_DEG);
  }

  // Beam constant: light returned by a flat wall straight ahead at 1 mm.
  static double beamConstant(double sigma){
    int n=SimulationSettings.DIFFUSION_RAYS;double span=SimulationSettings.DIFFUSION_SPAN_SIGMA*sigma,step=2*span/(n-1),c=0;
    for(int i=0;i<n;i++){double a=-span+i*step,ca=Math.cos(a);c+=pattern(a,sigma)*pattern(a,sigma)*albedoDiffuse()*ca*ca*ca*step;}
    return c;
  }

  // Light that leaves a lit spot (hx,hy) in direction (dx,dy), lands on another
  // wall, is scattered there (diffuse part) and reaches the receiver.
  // 'power' is the light travelling along this path. Returns received light.
  static double secondWall(Sensor s,TwinModel m,double sigma,double hx,double hy,double dx,double dy,Wall from,double power,ArrayList<double[]> paths){
    Hit h2=trace(m.walls,hx,hy,dx,dy,from);
    if(h2==null)return 0;
    double px=hx+h2.t*dx,py=hy+h2.t*dy,ux=s.sx-px,uy=s.sy-py,r3=Math.hypot(ux,uy);
    if(r3<1e-6)return 0;
    ux/=r3;uy/=r3;
    // The second spot must be lit and seen from the same side of its wall.
    double inSide=(hx-px)*h2.nx+(hy-py)*h2.ny,outSide=ux*h2.nx+uy*h2.ny;
    if(inSide*outSide<=0)return 0;
    double b=Navigator.wrap(Math.atan2(-uy,-ux)-s.heading),rb=pattern(b,sigma);
    if(rb<1e-4)return 0;
    Hit back=trace(m.walls,s.sx,s.sy,-ux,-uy,null);
    if(back==null||back.t<r3-0.01)return 0;               // Blocked by another wall.
    double c=power*albedoDiffuse()*Math.abs(outSide)*rb/(r3*r3);
    if(m.recording&&c>0)paths.add(new double[]{hx,hy,px,py,c});
    return c;
  }

  // Returns a raw ADC value (0..4095, lower = stronger) and fills the sensor's
  // ray/bounce lists for drawing.
  static double reading(Sensor s,TwinModel m){
    // Wall reflectances: the wall returns WALL_ALBEDO of the light (the rest is
    // absorbed); of that, WALL_MIRROR_FRACTION bounces like a mirror.
    double sigma=sigma(s),mirror=albedoMirror(),diffuse=albedoDiffuse();
    int n=SimulationSettings.DIFFUSION_RAYS;double span=SimulationSettings.DIFFUSION_SPAN_SIGMA*sigma,step=2*span/(n-1);
    double direct=0,indirect=0,scattered=0;
    for(int i=0;i<n;i++){
      double a=-span+i*step,dx=Math.cos(s.heading+a),dy=Math.sin(s.heading+a),e=pattern(a,sigma);
      Hit h=trace(m.walls,s.sx,s.sy,dx,dy,null);
      if(h==null){
        if(m.recording)s.rays.add(new double[]{s.sx+SimulationSettings.IR_MAX_RANGE_MM*dx,s.sy+SimulationSettings.IR_MAX_RANGE_MM*dy,0,e});
        continue;
      }
      double hx=s.sx+h.t*dx,hy=s.sy+h.t*dy,dot=dx*h.nx+dy*h.ny,cos1=Math.abs(dot);
      direct+=e*e*diffuse*cos1/(h.t*h.t)*step;
      if(m.recording){
        boolean shown=h.t<SimulationSettings.IR_MAX_RANGE_MM;
        double len=shown?h.t:SimulationSettings.IR_MAX_RANGE_MM;
        // For the animation only: chance that a drawn pulse on this ray comes
        // back into the receiver. Same physics as the reading: matte
        // reflectance x cos(incidence) x inverse-square fall-off.
        double ref=SimulationSettings.RETURN_PULSE_REFERENCE_MM;
        double pReturn=shown?Math.min(SimulationSettings.RETURN_PULSE_MAX_CHANCE,diffuse*cos1*e*(ref*ref)/(h.t*h.t)):0;
        s.rays.add(new double[]{s.sx+len*dx,s.sy+len*dy,shown?1:0,e,pReturn});
      }
      if(!SimulationSettings.IR_MULTIPATH)continue;
      double power=e*step;                               // Light carried by this beam ray.
      // (a) Mirror part: bounces like a mirror towards another side of the box.
      if(mirror>0){
        double rx=dx-2*dot*h.nx,ry=dy-2*dot*h.ny;
        double c=secondWall(s,m,sigma,hx,hy,rx,ry,h.wall,power*mirror,s.bounces);
        indirect+=c;
      }
      // (b) DIFFUSE SCATTERING: the matte part of the wall scatters light in
      //     all directions (Lambertian, strongest along the wall normal). Some
      //     of it lands on other sides of the box, which scatter it again and
      //     part of that reaches the receiver.
      if(SimulationSettings.IR_DIFFUSE_SCATTER&&diffuse>0){
        double onx=dot>0?-h.nx:h.nx,ony=dot>0?-h.ny:h.ny;   // Wall normal facing back into the room.
        double base=Math.atan2(ony,onx);
        int k=SimulationSettings.SCATTER_RAYS;double dphi=Math.PI/k;
        for(int j=0;j<k;j++){
          double phi=-Math.PI/2+(j+0.5)*dphi;
          double share=Math.cos(phi)*dphi/2*SimulationSettings.SCATTER_IN_PLANE_FRACTION;
          double c=secondWall(s,m,sigma,hx,hy,Math.cos(base+phi),Math.sin(base+phi),h.wall,power*diffuse*share,s.scatter);
          scattered+=c;
        }
      }
    }
    double all=direct+indirect+scattered,total=all*(s.side==0?1:SimulationSettings.REAR_IR_GAIN);
    s.indirectShare=all>0?(indirect+scattered)/all:0;
    s.scatterShare=all>0?scattered/all:0;
    s.directLight=direct;s.indirectLight=indirect+scattered;
    if(total<=0)return 4095;
    // Equivalent straight-ahead flat-wall distance, then the calibrated curve.
    return TwinModel.frontReading(Math.sqrt(beamConstant(sigma)/total));
  }
}
